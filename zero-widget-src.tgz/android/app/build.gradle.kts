plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val run = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()

android {
    namespace = "app.zero.widget"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.zero.widget"
        minSdk = 31
        targetSdk = 35
        versionCode = run
        versionName = "2.0.$run"
    }

    // Throwaway signing key for this personal app. It must stay the same between
    // builds so updates install over the old version and Google sign-in keeps working.
    signingConfigs {
        create("zero") {
            storeFile = file("zero-widget.jks")
            storePassword = "zerowidget"
            keyAlias = "zero"
            keyPassword = "zerowidget"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("zero")
        }
        debug {
            signingConfig = signingConfigs.getByName("zero")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false; checkReleaseBuilds = false }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("com.google.android.gms:play-services-auth:21.2.0")
    implementation("androidx.webkit:webkit:1.12.1")
}
