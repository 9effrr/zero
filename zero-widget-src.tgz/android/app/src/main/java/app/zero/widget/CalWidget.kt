package app.zero.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.graphics.Typeface
import android.util.SizeF
import android.view.View
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Month calendar widget (like Google Calendar's) with the chosen day's events and tasks underneath.
 * Small sizes show the whole month only; taller sizes add the day list below it.
 */
class CalWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        render(ctx)
        Sync.schedule(ctx)
    }

    override fun onEnabled(ctx: Context) {
        Sync.schedule(ctx)
        Sync.now(ctx)
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, mgr: AppWidgetManager, id: Int, opts: Bundle) {
        render(ctx)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        val sp = ctx.getSharedPreferences("calwidget", Context.MODE_PRIVATE)
        when (intent.action) {
            ACTION_PREV -> sp.edit().putInt("offset", sp.getInt("offset", 0) - 1).apply()
            ACTION_NEXT -> sp.edit().putInt("offset", sp.getInt("offset", 0) + 1).apply()
            ACTION_TODAY -> sp.edit().putInt("offset", 0).remove("sel").apply()
            ACTION_PICK -> {
                val d = intent.getStringExtra("day") ?: return
                val e = sp.edit().putString("sel", d)
                // Tapping a day from the previous/next month moves the calendar there.
                intent.getIntExtra("shift", 0).let { if (it != 0) e.putInt("offset", sp.getInt("offset", 0) + it) }
                e.apply()
            }
            else -> return
        }
        render(ctx)
    }

    companion object {
        const val ACTION_PREV = "app.zero.widget.CAL_PREV"
        const val ACTION_NEXT = "app.zero.widget.CAL_NEXT"
        const val ACTION_TODAY = "app.zero.widget.CAL_TODAY"
        const val ACTION_PICK = "app.zero.widget.CAL_PICK"

        private val EVENT_DOT = Zero.BLUE
        private val TASK_DOT = 0xFFDDBF9F.toInt()

        private fun broadcast(ctx: Context, code: Int, action: String, fill: (Intent) -> Unit = {}): PendingIntent {
            val i = Intent(ctx, CalWidget::class.java).setAction(action)
            fill(i)
            return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }

        private fun open(ctx: Context, code: Int, url: String): PendingIntent =
            PendingIntent.getActivity(
                ctx, code,
                Intent(ctx, OpenActivity::class.java).setData(Uri.parse(url)),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        /** Called whenever data changes (sync, app pause, midnight). */
        fun render(ctx: Context) {
            try { renderNow(ctx) } catch (e: Exception) {
                Prefs(ctx).lastError = "cal: " + e.javaClass.simpleName + ": " + (e.message ?: "")
            }
        }

        private fun renderNow(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, CalWidget::class.java))
            if (ids.isEmpty()) return

            val sp = ctx.getSharedPreferences("calwidget", Context.MODE_PRIVATE)
            val today = Data.todayKey()
            // A selection left over from an earlier day falls back to today.
            val stamp = sp.getString("stamp", null)
            if (stamp != today) sp.edit().putString("stamp", today).putInt("offset", 0).remove("sel").apply()
            val sel = sp.getString("sel", null) ?: today
            val offset = sp.getInt("offset", 0)

            // The launcher picks the biggest layout that fits, so the whole month stays visible at any size.
            val compact = build(ctx, R.layout.cal_widget_small, R.layout.cal_row, R.layout.cal_cell_compact, offset, sel, false)
            val small = build(ctx, R.layout.cal_widget_small, R.layout.cal_row, R.layout.cal_cell, offset, sel, false)
            val full = build(ctx, R.layout.cal_widget, R.layout.cal_row_fixed, R.layout.cal_cell, offset, sel, true)
            val views = RemoteViews(
                mapOf(
                    SizeF(100f, 100f) to compact,
                    SizeF(100f, 260f) to small,
                    SizeF(100f, 370f) to full
                )
            )
            mgr.updateAppWidget(ids, views)
        }

        private fun build(ctx: Context, layout: Int, rowLayout: Int, cellLayout: Int, offset: Int, sel: String, withList: Boolean): RemoteViews {
            val dotted = cellLayout == R.layout.cal_cell
            val pkg = ctx.packageName
            val rv = RemoteViews(pkg, layout)
            val today = Data.todayKey()

            // First day of the shown month.
            val month = Calendar.getInstance().apply {
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                add(Calendar.MONTH, offset)
            }
            val shownMonth = month.get(Calendar.MONTH)
            rv.setTextViewText(R.id.month, SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(month.time))

            // Grid starts on the locale's first weekday.
            val first = month.firstDayOfWeek
            val start = (month.clone() as Calendar).apply {
                val back = (get(Calendar.DAY_OF_WEEK) - first + 7) % 7
                add(Calendar.DAY_OF_MONTH, -back)
            }
            val daysInMonth = month.getActualMaximum(Calendar.DAY_OF_MONTH)
            val lead = (month.get(Calendar.DAY_OF_WEEK) - first + 7) % 7
            val weeks = (lead + daysInMonth + 6) / 7
            val end = (start.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, weeks * 7) }

            // Weekday letters.
            rv.removeAllViews(R.id.dows)
            val dowFmt = SimpleDateFormat("EEEEE", Locale.getDefault())
            val d0 = (start.clone() as Calendar)
            for (i in 0 until 7) {
                val c = RemoteViews(pkg, R.layout.cal_dow)
                c.setTextViewText(R.id.dow, dowFmt.format(d0.time))
                rv.addView(R.id.dows, c)
                d0.add(Calendar.DAY_OF_MONTH, 1)
            }

            val evDays = Data.eventDays(ctx, start, end)
            val tkDays = Data.taskDays(ctx)

            rv.removeAllViews(R.id.grid)
            val d = (start.clone() as Calendar)
            var idx = 0
            for (w in 0 until weeks) {
                val row = RemoteViews(pkg, rowLayout)
                for (i in 0 until 7) {
                    val key = Data.keyOf(d)
                    val inMonth = d.get(Calendar.MONTH) == shownMonth
                    val cell = RemoteViews(pkg, cellLayout)
                    val marked = key in evDays || key in tkDays
                    val num = d.get(Calendar.DAY_OF_MONTH).toString()
                    if (!dotted && marked && key != today) {
                        // No room for dots: busy days show in bold sand instead.
                        val b = SpannableStringBuilder(num)
                        b.setSpan(StyleSpan(Typeface.BOLD), 0, b.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        cell.setTextViewText(R.id.num, b)
                    } else cell.setTextViewText(R.id.num, num)
                    val bg = when {
                        key == today -> R.drawable.cal_today
                        key == sel -> R.drawable.cal_sel
                        else -> R.drawable.cal_none
                    }
                    cell.setInt(R.id.num, "setBackgroundResource", bg)
                    cell.setTextColor(
                        R.id.num,
                        when {
                            key == today -> 0xFF0B0B0C.toInt()
                            !dotted && marked && inMonth -> TASK_DOT
                            inMonth -> 0xFFECE6DE.toInt()
                            else -> 0xFF56565B.toInt()
                        }
                    )
                    if (dotted) {
                    val dots = SpannableStringBuilder()
                    if (key in evDays) dots.append("●", ForegroundColorSpan(EVENT_DOT), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    if (key in tkDays) dots.append("●", ForegroundColorSpan(TASK_DOT), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    if (dots.isEmpty()) dots.append(" ")
                    cell.setTextViewText(R.id.dots, dots)
                    }

                    val shift = when {
                        inMonth -> 0
                        d.before(month) -> -1
                        else -> 1
                    }
                    val pi = if (withList) {
                        broadcast(ctx, 200 + idx, ACTION_PICK) { it.putExtra("day", key).putExtra("shift", shift).setData(Uri.parse("zero://day/$key")) }
                    } else {
                        // Calendar-only size: a tap opens that day in the app.
                        open(ctx, 300 + idx, Zero.BASE + "?d=" + key)
                    }
                    cell.setOnClickPendingIntent(R.id.cell, pi)
                    row.addView(R.id.crow, cell)
                    d.add(Calendar.DAY_OF_MONTH, 1)
                    idx++
                }
                rv.addView(R.id.grid, row)
            }

            rv.setOnClickPendingIntent(R.id.prev, broadcast(ctx, 101, ACTION_PREV))
            rv.setOnClickPendingIntent(R.id.next, broadcast(ctx, 102, ACTION_NEXT))
            rv.setOnClickPendingIntent(R.id.month, broadcast(ctx, 103, ACTION_TODAY))
            rv.setOnClickPendingIntent(R.id.add, open(ctx, 104, Zero.BASE + "?a=add"))

            if (withList) fillList(ctx, rv, sel, today)
            return rv
        }

        private fun fillList(ctx: Context, rv: RemoteViews, sel: String, today: String) {
            val p = Prefs(ctx)
            val day = Calendar.getInstance().apply {
                val (y, m, dd) = sel.split("-").map { it.toInt() }
                set(y, m - 1, dd, 0, 0, 0); set(Calendar.MILLISECOND, 0)
            }
            val events = Data.eventsOn(ctx, day)
            val tasks = if (p.connected) Data.tasksOn(ctx, sel) else null
            val rows = (events ?: emptyList()) + (tasks ?: emptyList())

            val label = if (sel == today) "Today · " + SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(day.time)
            else SimpleDateFormat("EEEE d MMM", Locale.getDefault()).format(day.time)
            rv.setTextViewText(R.id.daylabel, label)
            rv.setOnClickPendingIntent(R.id.daylabel, open(ctx, 105, Zero.BASE + "?d=" + sel))

            val items = RemoteViews.RemoteCollectionItems.Builder().setHasStableIds(false).setViewTypeCount(1)
            rows.forEachIndexed { i, r ->
                val row = RemoteViews(ctx.packageName, R.layout.widget_row)
                row.setTextViewText(R.id.rt, r.title)
                row.setTextViewText(R.id.rm, r.meta)
                row.setViewVisibility(R.id.rm, if (r.meta.isEmpty()) View.GONE else View.VISIBLE)
                row.setInt(R.id.bar, "setColorFilter", r.color)
                row.setOnClickFillInIntent(R.id.row, Intent().setData(Uri.parse(r.url)))
                items.addItem(i.toLong(), row)
            }
            rv.setRemoteAdapter(R.id.list, items.build())
            rv.setEmptyView(R.id.list, R.id.empty)
            rv.setPendingIntentTemplate(
                R.id.list,
                PendingIntent.getActivity(
                    ctx, 106, Intent(ctx, OpenActivity::class.java),
                    PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            val setup = PendingIntent.getActivity(
                ctx, 107, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val status = when {
                events == null -> "Allow calendar access · tap"
                !p.connected || p.needsSignIn -> "Connect Google to show tasks · tap"
                else -> ""
            }
            rv.setTextViewText(R.id.status, status)
            rv.setViewVisibility(R.id.status, if (status.isEmpty()) View.GONE else View.VISIBLE)
            rv.setOnClickPendingIntent(R.id.status, setup)
            rv.setTextViewText(R.id.empty, "Nothing on this day")
        }
    }
}
