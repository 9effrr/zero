package app.zero.widget

import android.accounts.Account
import android.content.Context
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.Tasks
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** Reads Zero's data file (Drive › Zero › zero-data.json) with the same Google project as the web app. */
object Drive {

    fun request(email: String?): AuthorizationRequest {
        val b = AuthorizationRequest.builder().setRequestedScopes(Zero.SCOPES.map { Scope(it) })
        if (!email.isNullOrBlank()) b.setAccount(Account(email, "com.google"))
        return b.build()
    }

    /** Silent token, or null if the user has to sign in again from the app. */
    fun token(ctx: Context): String? {
        val p = Prefs(ctx)
        val res = Tasks.await(Identity.getAuthorizationClient(ctx).authorize(request(p.email)), 30, TimeUnit.SECONDS)
        if (res.hasResolution()) {
            p.needsSignIn = true
            return null
        }
        p.needsSignIn = false
        return res.accessToken
    }

    private fun get(url: String, token: String): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 30000
        c.setRequestProperty("Authorization", "Bearer $token")
        return try {
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            code to body
        } finally {
            c.disconnect()
        }
    }

    private fun findFile(token: String): Pair<Int, String?> {
        val q = URLEncoder.encode("name='${Zero.DATA_FILE}' and trashed=false", "UTF-8")
        val (code, body) = get(
            "https://www.googleapis.com/drive/v3/files?q=$q&spaces=drive&orderBy=modifiedTime%20desc&pageSize=1&fields=files(id)",
            token
        )
        if (code !in 200..299) return code to null
        val files = JSONObject(body).optJSONArray("files")
        return code to (if (files != null && files.length() > 0) files.getJSONObject(0).optString("id") else null)
    }

    /** Downloads the data file into the app's private cache. */
    fun refresh(ctx: Context) {
        val p = Prefs(ctx)
        if (!p.connected) return
        var tok = token(ctx) ?: return

        for (attempt in 0..1) {
            var id = p.fileId
            if (id == null) {
                val (code, found) = findFile(tok)
                if (code == 401 && attempt == 0) { GoogleAuthUtil.clearToken(ctx, tok); tok = token(ctx) ?: return; continue }
                if (found == null) { p.lastError = if (code in 200..299) "Zero's data file wasn't found in your Drive yet" else "Drive error $code"; return }
                id = found
                p.fileId = id
            }
            val (code, body) = get("https://www.googleapis.com/drive/v3/files/$id?alt=media", tok)
            when {
                code in 200..299 -> {
                    JSONObject(body) // validate before replacing the cache
                    val f = Data.cacheFile(ctx)
                    val tmp = File(f.parentFile, f.name + ".tmp")
                    tmp.writeText(body, Charsets.UTF_8)
                    tmp.renameTo(f)
                    p.lastSync = System.currentTimeMillis()
                    p.lastError = null
                    return
                }
                code == 401 && attempt == 0 -> { GoogleAuthUtil.clearToken(ctx, tok); tok = token(ctx) ?: return }
                code == 404 && attempt == 0 -> p.fileId = null
                else -> { p.lastError = "Drive error $code"; return }
            }
        }
    }
}
