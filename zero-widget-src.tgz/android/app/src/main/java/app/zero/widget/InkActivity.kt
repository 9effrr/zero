package app.zero.widget

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import android.speech.RecognizerIntent
import androidx.core.content.FileProvider
import androidx.core.graphics.PathParser
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

/** Notes on the tablet: type, or write and draw with the S Pen on an endless dark page. */
class InkActivity : ComponentActivity(), InkView.Host {

    companion object {
        const val EXTRA_ID = "id"

        private fun dir(ctx: Context) = File(ctx.filesDir, "ink").apply { mkdirs() }
        fun openFile(ctx: Context) = File(ctx.cacheDir, "ink-open.json")

        /** Notes edited here wait in files until the app's page has taken them in (see MainActivity.Bridge). */
        fun pending(ctx: Context): List<JSONObject> =
            (dir(ctx).listFiles() ?: emptyArray()).mapNotNull { f -> try { JSONObject(f.readText()) } catch (e: Exception) { null } }

        fun ack(ctx: Context, id: String, updatedAt: Long) {
            val f = File(dir(ctx), safe(id) + ".json")
            try { if (f.exists() && JSONObject(f.readText()).optLong("updatedAt") <= updatedAt) f.delete() } catch (e: Exception) { }
        }

        fun store(ctx: Context, o: JSONObject) {
            val f = File(dir(ctx), safe(o.getString("id")) + ".json")
            val tmp = File(f.path + ".tmp")
            tmp.writeText(o.toString()); tmp.renameTo(f)
        }

        fun stored(ctx: Context, id: String): JSONObject? =
            File(dir(ctx), safe(id) + ".json").takeIf { it.exists() }?.let { try { JSONObject(it.readText()) } catch (e: Exception) { null } }

        private fun safe(id: String) = id.replace(Regex("[^A-Za-z0-9_-]"), "_")

        val COLORS = intArrayOf(
            0xFFECE6DE.toInt(), 0xFFC29B78.toInt(), 0xFFDDBF9F.toInt(), 0xFF93AFC2.toInt(),
            0xFF4DABF7.toInt(), 0xFF9CC2A4.toInt(), 0xFF69DB7C.toInt(), 0xFFFFD43B.toInt(),
            0xFFE5916B.toInt(), 0xFFFF6B6B.toInt(), 0xFFB197FC.toInt(), 0xFFF783AC.toInt(),
        )
        val PAGE_COLORS = arrayOf("#0B0B0C", "#18181A", "#18222F", "#1A2621", "#251E2C", "#2A221E", "#23262C", "#29261E")
        val TOOLS = listOf(Ink.PEN to "Pen", Ink.BALL to "Ballpoint", Ink.PENCIL to "Pencil", Ink.MARKER to "Marker", InkView.ERASER to "Eraser", InkView.LASSO to "Lasso")

        private val BG = Color.parseColor("#0B0B0C")
        private val S1 = Color.parseColor("#151517")
        private val S2 = Color.parseColor("#1E1E21")
        private val LINE = Color.parseColor("#1C1C1F")
        private val TX = Color.parseColor("#ECE6DE")
        private val TX2 = Color.parseColor("#BDBCB9")
        private val MUT = Color.parseColor("#86868C")
        private val DIM = Color.parseColor("#56565B")
        private val SAND = Color.parseColor("#C29B78")
        private val SAND2 = Color.parseColor("#DDBF9F")
    }

    private lateinit var id: String
    private var createdAt: String? = null
    private lateinit var ink: InkView
    private lateinit var scroll: NoteScroll
    private lateinit var page: FrameLayout
    private lateinit var textCol: LinearLayout
    private lateinit var title: EditText
    private lateinit var rule: View
    private lateinit var body: EditText
    private lateinit var meta: TextView
    private lateinit var toolsBar: View
    private lateinit var textBar: View
    private lateinit var stage: FrameLayout
    private var pageColor: String? = null
    private val fmtBtns = HashMap<String, TextView>()
    private val pageSwatches = ArrayList<Swatch>()
    private var dirBtn: IconBtn? = null
    // voice typing: Google's speech recogniser writes what you say into the note
    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) {
            val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!t.isNullOrBlank()) insertDictation(t)
        }
    }
    private lateinit var selBar: View
    private lateinit var modeType: TextView
    private lateinit var modePen: TextView
    private lateinit var undoBtn: IconBtn
    private lateinit var redoBtn: IconBtn
    private lateinit var fingerChip: TextView
    private lateinit var sizeBar: SeekBar
    private lateinit var sizeDot: SizeDot
    private val toolBtns = HashMap<String, ToolChip>()
    private val swatches = ArrayList<Swatch>()

    private val prefs by lazy { getSharedPreferences("ink", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    // autosave waits while the pen is on the page, and does the heavy part (encoding ink, writing the file) off the UI thread
    private val io = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val saver = object : Runnable { override fun run() { if (::ink.isInitialized && ink.busy()) handler.postDelayed(this, 700) else save() } }
    private var deleted = false
    private var dirty = false
    private var loading = true

    private fun dp(v: Float) = v * resources.displayMetrics.density
    private fun dpi(v: Float) = dp(v).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val src = try { JSONObject(openFile(this).readText()) } catch (e: Exception) { JSONObject() }
        id = intent.getStringExtra(EXTRA_ID) ?: src.optString("id", "")
        if (id.isEmpty()) { finish(); return }
        var note = if (src.optString("id") == id) src else JSONObject().put("id", id)
        stored(this, id)?.let { if (it.optLong("updatedAt") >= note.optLong("updatedAt")) note = it }
        createdAt = note.optString("createdAt").ifEmpty { null }

        buildUi()

        ink.load(Ink.decode(note.optJSONObject("ink")))
        title.setText(note.optString("title"))
        val html = note.optString("html")
        if (html.isNotEmpty() && html != "null") body.setText(RichText.fromHtml(html)) else body.setText(note.optString("text"))
        pageColor = note.optString("color").takeIf { it.startsWith("#") }
        applyPageColor()
        updateMeta(note.optLong("updatedAt", System.currentTimeMillis()))
        loading = false

        val firstPen = prefs.getBoolean("penMode", true)
        setPenMode(firstPen)
        if (!firstPen && title.text.isEmpty() && body.text.isEmpty()) title.requestFocus()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { close() }
        })
    }

    /* ---------------- layout ---------------- */

    @SuppressLint("SetTextI18n")
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }

        // Row 1: back, meta, Type/Pen, undo, redo, finger, delete
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(8f), dpi(6f), dpi(10f), dpi(6f))
        }
        bar.addView(IconBtn(this, "back").apply { setOnClickListener { close() }; contentDescription = "Back" }, lp(dpi(48f), dpi(48f)))
        meta = TextView(this).apply { setTextColor(MUT); textSize = 12f; maxLines = 1; setPadding(dpi(6f), 0, dpi(6f), 0) }
        bar.addView(meta, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(dpi(4f), dpi(4f), dpi(4f), dpi(4f))
            background = round(S1, dp(14f))
        }
        modeType = segBtn("Type") { setPenMode(false) }
        modePen = segBtn("Pen") { setPenMode(true) }
        seg.addView(modeType, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dpi(40f)))
        seg.addView(modePen, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dpi(40f)))
        bar.addView(seg, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dpi(10f) })

        undoBtn = IconBtn(this, "undo").apply { setOnClickListener { ink.undo() }; contentDescription = "Undo" }
        redoBtn = IconBtn(this, "redo").apply { setOnClickListener { ink.redo() }; contentDescription = "Redo" }
        bar.addView(undoBtn, lp(dpi(48f), dpi(48f)))
        bar.addView(redoBtn, lp(dpi(48f), dpi(48f)))

        fingerChip = TextView(this).apply {
            textSize = 13f; gravity = Gravity.CENTER; setPadding(dpi(14f), 0, dpi(14f), 0)
            setOnClickListener { setFinger(!ink.fingerDraws) }
        }
        bar.addView(fingerChip, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dpi(40f)).apply { marginStart = dpi(6f); marginEnd = dpi(4f) })
        bar.addView(IconBtn(this, "share").apply { setOnClickListener { shareNote() }; contentDescription = "Share note" }, lp(dpi(48f), dpi(48f)))
        bar.addView(IconBtn(this, "trash").apply { setOnClickListener { confirmDelete() }; contentDescription = "Delete note" }, lp(dpi(48f), dpi(48f)))
        root.addView(bar, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Row 2: tools, colours, size (pen mode only)
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dpi(12f), 0, dpi(12f), dpi(8f)) }
        for ((k, label) in TOOLS) {
            val chip = ToolChip(this, k, label).apply { setOnClickListener { pickTool(k) } }
            toolBtns[k] = chip
            tools.addView(chip, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dpi(54f)))
        }
        tools.addView(divider(), lp(dpi(1f), dpi(30f)).apply { marginStart = dpi(10f); marginEnd = dpi(12f) })
        for (c in COLORS) {
            val sw = Swatch(this, c).apply { setOnClickListener { pickColor(c) } }
            swatches.add(sw)
            tools.addView(sw, lp(dpi(34f), dpi(34f)).apply { marginEnd = dpi(4f) })
        }
        tools.addView(divider(), lp(dpi(1f), dpi(30f)).apply { marginStart = dpi(8f); marginEnd = dpi(10f) })
        sizeDot = SizeDot(this)
        tools.addView(sizeDot, lp(dpi(34f), dpi(34f)))
        sizeBar = SeekBar(this).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(SAND); thumbTintList = ColorStateList.valueOf(SAND2)
            progressBackgroundTintList = ColorStateList.valueOf(S2)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) { if (user) setSize(p) }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        tools.addView(sizeBar, lp(dpi(170f), dpi(40f)))
        toolsBar = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(tools) }
        root.addView(toolsBar, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Row 2 in type mode: headings, weight, page colour
        val tb = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dpi(12f), 0, dpi(12f), dpi(8f)) }
        fun fmt(label: String, key: String, tf: Int, size: Float = 14f) = TextView(this).apply {
            text = label; textSize = size; gravity = Gravity.CENTER; setPadding(dpi(16f), 0, dpi(16f), 0)
            setTextColor(TX2); typeface = android.graphics.Typeface.create(if (key == "light") "sans-serif-light" else "sans-serif", tf)
            background = round(S1, dp(12f)); contentDescription = key
            setOnClickListener { applyFmt(key) }
        }.also { fmtBtns[key] = it; fmtLabels[key] = label }
        for ((k, l) in listOf("h1" to "H1", "h2" to "H2", "p" to "Text")) tb.addView(fmt(l, k, android.graphics.Typeface.BOLD), lp(ViewGroup.LayoutParams.WRAP_CONTENT, dpi(40f)).apply { marginEnd = dpi(4f) })
        tb.addView(divider(), lp(dpi(1f), dpi(30f)).apply { marginStart = dpi(8f); marginEnd = dpi(12f) })
        tb.addView(fmt("B", "bold", android.graphics.Typeface.BOLD, 15f), lp(ViewGroup.LayoutParams.WRAP_CONTENT, dpi(40f)).apply { marginEnd = dpi(4f) })
        tb.addView(fmt("Aa", "regular", android.graphics.Typeface.NORMAL), lp(ViewGroup.LayoutParams.WRAP_CONTENT, dpi(40f)).apply { marginEnd = dpi(4f) })
        tb.addView(fmt("Aa", "light", android.graphics.Typeface.NORMAL), lp(ViewGroup.LayoutParams.WRAP_CONTENT, dpi(40f)))
        tb.addView(divider(), lp(dpi(1f), dpi(30f)).apply { marginStart = dpi(12f); marginEnd = dpi(12f) })
        refreshFmtGroups()
        // one button for writing direction, like Google Docs: tap to flip the paragraph right-to-left / left-to-right
        dirBtn = IconBtn(this, "dir-ltr").apply { setOnClickListener { flipDir() }; contentDescription = "Text direction"; background = round(S1, dp(12f)) }
        tb.addView(dirBtn, lp(dpi(48f), dpi(40f)).apply { marginEnd = dpi(4f) })
        tb.addView(divider(), lp(dpi(1f), dpi(30f)).apply { marginStart = dpi(8f); marginEnd = dpi(12f) })
        for ((k, l) in listOf("mic-ar" to "🎙  عربي", "mic-en" to "🎙  EN")) tb.addView(fmt(l, k, android.graphics.Typeface.BOLD, 13f), lp(ViewGroup.LayoutParams.WRAP_CONTENT, dpi(40f)).apply { marginEnd = dpi(4f) })
        tb.addView(divider(), lp(dpi(1f), dpi(30f)).apply { marginStart = dpi(12f); marginEnd = dpi(12f) })
        tb.addView(TextView(this).apply { text = "Page"; setTextColor(MUT); textSize = 12f; setPadding(0, 0, dpi(8f), 0) })
        for (hex in PAGE_COLORS) {
            val sw = Swatch(this, Color.parseColor(hex)).apply { setOnClickListener { pickPage(hex) }; contentDescription = "Page colour" }
            pageSwatches.add(sw)
            tb.addView(sw, lp(dpi(34f), dpi(34f)).apply { marginEnd = dpi(4f) })
        }
        textBar = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(tb) }
        root.addView(textBar, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(View(this).apply { setBackgroundColor(LINE) }, lp(ViewGroup.LayoutParams.MATCH_PARENT, 1))

        // The page: typed text, with the handwriting layer on top of it
        scroll = NoteScroll(this).apply { isFillViewport = true; isVerticalScrollBarEnabled = true; overScrollMode = View.OVER_SCROLL_NEVER }
        val center = FrameLayout(this)
        page = FrameLayout(this)
        textCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        title = edit(true)
        rule = View(this).apply { background = round(SAND, dp(2f)) }
        body = edit(false)
        textCol.addView(title, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        textCol.addView(rule, lp(10, 4))
        textCol.addView(body, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        ink = InkView(this) { scroll }.also { it.host = this }
        page.addView(textCol, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        page.addView(ink, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        center.addView(page, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        scroll.addView(center, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        scroll.onWidth = { w -> layoutPage(w) }
        scroll.onScroll = { ink.onScrolled() }

        stage = FrameLayout(this)
        stage.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        selBar = selectionBar()
        stage.addView(selBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dpi(24f) })
        selBar.visibility = View.GONE
        root.addView(stage, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val frame = FrameLayout(this).apply {
            setBackgroundColor(BG)
            addView(root, FrameLayout.LayoutParams(-1, -1))
            setOnApplyWindowInsetsListener { v, insets ->
                val i = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime() or WindowInsets.Type.displayCutout())
                v.setPadding(i.left, i.top, i.right, i.bottom)
                WindowInsets.CONSUMED
            }
        }
        setContentView(frame)

        // restore the last tool, colours and sizes
        ink.fingerDraws = prefs.getBoolean("finger", false)
        ink.eraseWhole = prefs.getBoolean("eraseWhole", true)
        ink.eraserSize = prefs.getFloat("size_eraser", 14f)
        pickTool(prefs.getString("tool", Ink.PEN) ?: Ink.PEN, remember = false)
        setFinger(ink.fingerDraws)
    }

    /** The page is at most 900dp wide, centred; everything on it scales with its width. */
    private fun layoutPage(viewW: Int) {
        val w = min(viewW, dpi(900f))
        if (w <= 0) return
        val s = w / Ink.PAGE
        (page.layoutParams as FrameLayout.LayoutParams).width = w
        val pad = (30 * s).toInt()
        title.setTextSize(TypedValue.COMPLEX_UNIT_PX, 34 * s)
        title.setLineHeight((34 * s * 1.35f).toInt().coerceAtLeast(1))
        title.setPadding(pad, (8 * s).toInt() + (14 * s).toInt(), pad, (13 * s).toInt())
        (rule.layoutParams as LinearLayout.LayoutParams).apply { width = (58 * s).toInt(); height = (4 * s).toInt().coerceAtLeast(2); marginStart = pad; bottomMargin = (21 * s).toInt() }
        body.setTextSize(TypedValue.COMPLEX_UNIT_PX, 24 * s)
        body.setLineHeight((24 * s * 1.85f).toInt().coerceAtLeast(1))
        body.setPadding(pad, 0, pad, (40 * s).toInt())
        ink.scale = s
        page.requestLayout()
    }

    private fun edit(isTitle: Boolean) = EditText(this).apply {
        background = null
        includeFontPadding = false
        setTextColor(if (isTitle) TX else TX2)
        setHintTextColor(DIM)
        hint = if (isTitle) "Title" else "Start writing…"
        gravity = Gravity.START or Gravity.TOP
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        if (isTitle) {
            paint.isFakeBoldText = false
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            imeOptions = EditorInfo.IME_ACTION_NEXT
        } else {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
        }
        isSingleLine = false
        addTextChangedListener(object : TextWatcher {
            var st = 0; var n = 0
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { st = a; n = c }
            override fun afterTextChanged(s: Editable?) {
                if (!isTitle && s != null) { RichText.typed(s, st, n); RichText.tidy(s); RichText.carryDir(s, st, n) }
                changed()
            }
        })
    }

    private fun selectionBar(): View {
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(6f), dpi(6f), dpi(6f), dpi(6f))
            background = round(S2, dp(18f)); elevation = dp(8f)
        }
        fun act(label: String, f: () -> Unit) = TextView(this).apply {
            text = label; setTextColor(TX); textSize = 14f; gravity = Gravity.CENTER
            setPadding(dpi(16f), 0, dpi(16f), 0); background = round(Color.TRANSPARENT, dp(12f))
            setOnClickListener { f() }
        }
        b.addView(TextView(this).apply { text = "Tap a colour to recolour"; setTextColor(MUT); textSize = 12f; setPadding(dpi(12f), 0, dpi(8f), 0) })
        b.addView(act("Duplicate") { ink.duplicateSelection() }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dpi(44f)))
        b.addView(act("Delete") { ink.deleteSelection() }.apply { setTextColor(Color.parseColor("#E88B7D")) }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dpi(44f)))
        b.addView(act("Done") { ink.clearSelection() }.apply { setTextColor(SAND2) }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dpi(44f)))
        return b
    }

    /* ---------------- modes & tools ---------------- */

    private fun setPenMode(on: Boolean) {
        ink.penMode = on
        scroll.penMode = on
        prefs.edit().putBoolean("penMode", on).apply()
        styleSeg(modePen, on); styleSeg(modeType, !on)
        toolsBar.visibility = if (on) View.VISIBLE else View.GONE
        textBar.visibility = if (on) View.GONE else View.VISIBLE
        fingerChip.visibility = if (on) View.VISIBLE else View.GONE
        if (on) {
            currentFocus?.clearFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(window.decorView.windowToken, 0)
        }
        if (!on) selBar.visibility = View.GONE
    }

    private fun setFinger(on: Boolean) {
        ink.fingerDraws = on
        prefs.edit().putBoolean("finger", on).apply()
        fingerChip.text = if (on) "Finger draws" else "Pen only"
        fingerChip.setTextColor(if (on) BG else TX2)
        fingerChip.background = if (on) round(SAND2, dp(12f)) else stroke(S1, LINE, dp(12f))
    }

    private fun pickTool(k: String, remember: Boolean = true) {
        if (k == InkView.ERASER && ink.tool == InkView.ERASER && remember) {
            ink.eraseWhole = !ink.eraseWhole
            prefs.edit().putBoolean("eraseWhole", ink.eraseWhole).apply()
            toast(if (ink.eraseWhole) "Eraser: whole strokes" else "Eraser: only where you rub")
        }
        ink.tool = k
        if (remember) prefs.edit().putString("tool", k).apply()
        val inkTool = k != InkView.ERASER && k != InkView.LASSO
        if (inkTool) {
            ink.color = prefs.getInt("color_$k", if (k == Ink.MARKER) 0xFFFFD43B.toInt() else COLORS[0])
            ink.penWidth = prefs.getFloat("size_$k", defWidth(k))
        }
        for ((key, chip) in toolBtns) chip.setOn(key == k, if (key == InkView.ERASER) (if (ink.eraseWhole) "Eraser" else "Eraser ½") else null)
        val colourable = k != InkView.ERASER
        for (sw in swatches) { sw.isEnabled = colourable; sw.alpha = if (colourable) 1f else 0.35f; sw.on = inkTool && sw.color == ink.color; sw.invalidate() }
        sizeBar.visibility = if (k == InkView.LASSO) View.INVISIBLE else View.VISIBLE
        sizeDot.visibility = sizeBar.visibility
        val (lo, hi) = range(k)
        val cur = if (k == InkView.ERASER) ink.eraserSize else ink.penWidth
        sizeBar.progress = (((cur - lo) / (hi - lo)) * 100).toInt().coerceIn(0, 100)
        refreshDot()
    }

    private fun defWidth(k: String) = when (k) { Ink.PEN -> 3f; Ink.BALL -> 2.4f; Ink.PENCIL -> 2f; Ink.MARKER -> 18f; else -> 3f }
    private fun range(k: String) = when (k) { Ink.MARKER -> 8f to 40f; InkView.ERASER -> 5f to 60f; Ink.PENCIL -> 0.8f to 8f; else -> 1f to 12f }

    private fun setSize(p: Int) {
        val (lo, hi) = range(ink.tool)
        val v = lo + (hi - lo) * p / 100f
        if (ink.tool == InkView.ERASER) { ink.eraserSize = v; prefs.edit().putFloat("size_eraser", v).apply() }
        else { ink.penWidth = v; prefs.edit().putFloat("size_${ink.tool}", v).apply() }
        refreshDot()
    }

    private fun pickColor(c: Int) {
        val k = ink.tool
        if (k == InkView.LASSO) { ink.recolorSelection(c); return }
        if (k == InkView.ERASER) return
        ink.color = c
        prefs.edit().putInt("color_$k", c).apply()
        for (sw in swatches) { sw.on = sw.color == c; sw.invalidate() }
        refreshDot()
    }

    private fun refreshDot() {
        val k = ink.tool
        sizeDot.set(if (k == InkView.ERASER) MUT else Ink.withAlpha(ink.color, Ink.alpha(k)),
            (if (k == InkView.ERASER) ink.eraserSize * 2 else ink.penWidth) * ink.scale, k == InkView.ERASER)
    }

    /* ---------------- text formatting & page colour ---------------- */

    /* Headings and weight sit folded: one chip shows the current choice; tap it to see the three, pick one, and it folds again */
    private val fmtLabels = HashMap<String, String>()
    private val fmtGroups = mapOf("blk" to listOf("h1", "h2", "p"), "wt" to listOf("bold", "regular", "light"))
    private val fmtCur = hashMapOf("blk" to "p", "wt" to "regular")
    private var fmtOpen: String? = null

    private fun refreshFmtGroups() {
        for ((g, keys) in fmtGroups) for (k in keys) {
            val v = fmtBtns[k] ?: continue
            val open = fmtOpen == g; val cur = fmtCur[g] == k
            v.visibility = if (open || cur) View.VISIBLE else View.GONE
            v.text = if (!open && cur) (fmtLabels[k] ?: k) + "  ▾" else (fmtLabels[k] ?: k)
            v.background = round(if (open && cur) SAND else S1, dp(12f))
            v.setTextColor(if (open && cur) BG else TX2)
        }
    }

    private fun applyFmt(key: String) {
        if (key.startsWith("mic-")) { dictate(if (key == "mic-ar") "ar-OM" else "en-US"); return }
        val g = fmtGroups.entries.firstOrNull { key in it.value }?.key
        if (g != null && fmtOpen != g) { fmtOpen = g; refreshFmtGroups(); return }
        if (g != null) { fmtCur[g] = key; fmtOpen = null; refreshFmtGroups() }
        if (key == "h1" || key == "h2" || key == "p") RichText.setBlock(body, key) else RichText.setWeight(body, key)
        if (!body.hasFocus()) body.requestFocus()
        changed()
    }

    private fun dictate(lang: String) {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
            .putExtra(RecognizerIntent.EXTRA_PROMPT, if (lang.startsWith("ar")) "تكلّم…" else "Speak…")
        try { speech.launch(i) } catch (e: Exception) { toast("Voice typing isn't available on this tablet") }
    }

    private fun insertDictation(t: String) {
        val s = body.text ?: return
        var p = body.selectionStart; if (p < 0 || p > s.length) p = s.length
        val pre = if (p > 0 && !s[p - 1].isWhitespace()) " " else ""
        s.insert(p, pre + t)
        try { body.setSelection(minOf(s.length, p + pre.length + t.length)) } catch (e: Exception) {}
        if (!body.hasFocus()) body.requestFocus()
        changed()
    }

    private fun flipDir() {
        if (!body.hasFocus()) body.requestFocus()
        val d = RichText.toggleDir(body)
        dirBtn?.let { it.kind = "dir-$d"; it.invalidate() }
        changed()
    }

    private fun refreshDir() {
        val b = dirBtn ?: return
        if (!::body.isInitialized) return
        body.post { val k = "dir-" + RichText.shownDir(body); if (b.kind != k) { b.kind = k; b.invalidate() } }
    }

    /** Share the note: its text, plus the handwriting as a picture when there is any. */
    private fun shareNote() {
        val t = title.text.toString().trim(); val b = RichText.plain(body.text ?: "").trim()
        val text = listOf(t, b).filter { it.isNotEmpty() }.joinToString("\n\n")
        val img = if (ink.strokes.isEmpty()) null else try { inkPng() } catch (e: Exception) { null }
        if (text.isEmpty() && img == null) { toast("Nothing to share yet"); return }
        val i = Intent(Intent.ACTION_SEND)
        if (t.isNotEmpty()) i.putExtra(Intent.EXTRA_SUBJECT, t)
        if (text.isNotEmpty()) i.putExtra(Intent.EXTRA_TEXT, text)
        if (img != null) {
            val uri = FileProvider.getUriForFile(this, "$packageName.files", img)
            i.type = "image/png"; i.putExtra(Intent.EXTRA_STREAM, uri); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } else i.type = "text/plain"
        try { startActivity(Intent.createChooser(i, "Share note").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } catch (e: Exception) { toast("Couldn't share") }
    }

    private fun inkPng(): File {
        var right = 0f; var bottom = 0f
        for (st in ink.strokes) { right = maxOf(right, st.bounds.right); bottom = maxOf(bottom, st.bounds.bottom) }
        val pad = 40f
        val w = right + pad; val h = bottom + pad
        val k = minOf(2f, 2400f / maxOf(1f, w), 6000f / maxOf(1f, h))
        val bmp = android.graphics.Bitmap.createBitmap(maxOf(1, (w * k).toInt()), maxOf(1, (h * k).toInt()), android.graphics.Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp); c.drawColor(Color.parseColor(pageColor ?: PAGE_COLORS[0]))
        Ink.drawAll(c, ink.strokes, k)
        val dir = File(cacheDir, "share").apply { mkdirs(); listFiles()?.forEach { it.delete() } }
        val name = (title.text.toString().trim().ifEmpty { "Note" }).replace(Regex("[^\\p{L}\\p{N} ._-]"), "_").take(60) + ".png"
        val f = File(dir, name)
        f.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        return f
    }

    private fun pickPage(hex: String) {
        pageColor = if (hex == PAGE_COLORS[0]) null else hex
        applyPageColor(); changed()
    }

    private fun applyPageColor() {
        val hex = pageColor ?: PAGE_COLORS[0]
        if (::stage.isInitialized) stage.setBackgroundColor(Color.parseColor(hex))
        for (sw in pageSwatches) { sw.on = Ink.colorHex(sw.color).equals(hex, true); sw.invalidate() }
    }

    /* ---------------- InkView.Host ---------------- */

    override fun inkChanged() = changed()
    override fun selectionChanged(count: Int) { selBar.visibility = if (count > 0) View.VISIBLE else View.GONE }
    override fun historyChanged(canUndo: Boolean, canRedo: Boolean) {
        undoBtn.isEnabled = canUndo; undoBtn.alpha = if (canUndo) 1f else 0.35f
        redoBtn.isEnabled = canRedo; redoBtn.alpha = if (canRedo) 1f else 0.35f
    }
    override fun minPageHeight(): Int = textCol.measuredHeight

    /* ---------------- saving ---------------- */

    private fun changed() {
        refreshDir()
        if (loading) return
        dirty = true
        handler.removeCallbacks(saver)
        handler.postDelayed(saver, 1200)
    }

    private fun isEmpty() = title.text.isBlank() && RichText.plain(body.text).isBlank() && ink.strokes.isEmpty()

    private fun save(final: Boolean = false) {
        handler.removeCallbacks(saver)
        val gone = deleted || (final && isEmpty())
        if (!gone && !dirty) return
        val t = System.currentTimeMillis()
        val o = JSONObject().put("id", id).put("updatedAt", t)
        val strokes = ink.strokes
        if (gone) o.put("deleted", true)
        else {
            o.put("title", title.text.toString()).put("text", RichText.plain(body.text))
                .put("html", RichText.toHtml(body.text)).put("color", pageColor ?: JSONObject.NULL)
                .put("deleted", false)
            createdAt?.let { o.put("createdAt", it) }
        }
        dirty = false
        val job = io.submit(Runnable {
            try {
                if (!gone) o.put("ink", if (strokes.isEmpty()) JSONObject.NULL else Ink.encode(strokes))
                store(this, o)
                runOnUiThread { if (!isDestroyed) updateMeta(t) }
            } catch (e: Exception) { runOnUiThread { dirty = true; toast("Couldn't save this note") } }
        })
        if (final) try { job.get(5, java.util.concurrent.TimeUnit.SECONDS) } catch (e: Exception) { }
    }

    override fun onPause() {
        super.onPause()
        save(final = isFinishing)
    }

    private fun close() {
        save(final = true)
        finish()
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setMessage("Delete this note?")
            .setPositiveButton("Delete") { _, _ -> deleted = true; save(final = true); finish() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateMeta(t: Long) {
        meta.text = SimpleDateFormat("d MMM, HH:mm", Locale.ENGLISH).format(Date(t))
    }

    private fun toast(s: String) = android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show()

    /* ---------------- little UI pieces ---------------- */

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
    private fun round(c: Int, r: Float) = GradientDrawable().apply { setColor(c); cornerRadius = r }
    private fun stroke(c: Int, line: Int, r: Float) = GradientDrawable().apply { setColor(c); cornerRadius = r; setStroke(dpi(1f), line) }
    private fun divider() = View(this).apply { setBackgroundColor(LINE) }

    private fun segBtn(label: String, f: () -> Unit) = TextView(this).apply {
        text = label; textSize = 14f; gravity = Gravity.CENTER; setPadding(dpi(18f), 0, dpi(18f), 0)
        setOnClickListener { f() }
    }

    private fun styleSeg(v: TextView, on: Boolean) {
        v.setTextColor(if (on) BG else TX2)
        v.background = if (on) round(SAND2, dp(10f)) else null
        v.paint.isFakeBoldText = on
        v.invalidate()
    }

    /** ScrollView that leaves every touch to the handwriting layer while in pen mode. */
    class NoteScroll(ctx: Context) : ScrollView(ctx) {
        var penMode = false
        var onWidth: ((Int) -> Unit)? = null
        var onScroll: (() -> Unit)? = null
        override fun onInterceptTouchEvent(ev: android.view.MotionEvent): Boolean = if (penMode) false else super.onInterceptTouchEvent(ev)
        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            super.onSizeChanged(w, h, ow, oh)
            if (w != ow) post { onWidth?.invoke(w) }
        }
        override fun onScrollChanged(l: Int, t: Int, ol: Int, ot: Int) { super.onScrollChanged(l, t, ol, ot); onScroll?.invoke() }
    }

    /** Line icons drawn in code, in the app's colours. */
    class IconBtn(ctx: Context, var kind: String) : View(ctx) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = TX }
        private val shapes = HashMap<String, Path>()
        private val d = resources.displayMetrics.density
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.8f * d; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = TX }
        private val path = Path()
        init { isClickable = true; background = android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(Color.argb(40, 255, 255, 255)), null, GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }) }
        override fun onDraw(c: Canvas) {
            val u = 1f * d; val ox = (width - 24 * u) / 2; val oy = (height - 24 * u) / 2
            c.save(); c.translate(ox, oy)
            path.rewind()
            // filled Material icons (24×24): share and the Google Docs text-direction marks
            val svg = when (kind) {
                "share" -> "M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92-1.31-2.92-2.92-2.92z"
                "dir-ltr" -> "M9 10v5h2V4h2v11h2V4h2V2H9C6.79 2 5 3.79 5 6s1.79 4 4 4zm12 8l-4-4v3H5v2h12v3l4-4z"
                "dir-rtl" -> "M10 10v5h2V4h2v11h2V4h2V2h-8C7.79 2 6 3.79 6 6s1.79 4 4 4zm-2 7v-3l-4 4 4 4v-3h12v-2H8z"
                else -> null
            }
            if (svg != null) {
                val sp = shapes.getOrPut(kind) { PathParser.createPathFromPathData(svg) }
                c.scale(u, u); c.drawPath(sp, fill); c.restore(); return
            }
            when (kind) {
                "back" -> { path.moveTo(15 * u, 5 * u); path.lineTo(8 * u, 12 * u); path.lineTo(15 * u, 19 * u) }
                "undo", "redo" -> {
                    if (kind == "redo") { c.scale(-1f, 1f, 12 * u, 12 * u) }
                    path.moveTo(9 * u, 8 * u); path.lineTo(15 * u, 8 * u)
                    path.arcTo(RectF(10 * u, 8 * u, 20 * u, 18 * u), -90f, 180f)
                    path.lineTo(8 * u, 18 * u)
                    path.moveTo(12 * u, 4.5f * u); path.lineTo(8.5f * u, 8 * u); path.lineTo(12 * u, 11.5f * u)
                }
                "trash" -> {
                    path.moveTo(4 * u, 7 * u); path.lineTo(20 * u, 7 * u)
                    path.moveTo(9 * u, 7 * u); path.lineTo(9 * u, 4.5f * u); path.lineTo(15 * u, 4.5f * u); path.lineTo(15 * u, 7 * u)
                    path.moveTo(6.5f * u, 7 * u); path.lineTo(7.5f * u, 20 * u); path.lineTo(16.5f * u, 20 * u); path.lineTo(17.5f * u, 7 * u)
                    path.moveTo(10.5f * u, 11 * u); path.lineTo(10.5f * u, 16 * u); path.moveTo(13.5f * u, 11 * u); path.lineTo(13.5f * u, 16 * u)
                }
            }
            c.drawPath(path, p)
            c.restore()
        }
    }

    /** A tool button: drawn icon with a small label underneath. */
    class ToolChip(ctx: Context, private val kind: String, private var label: String) : View(ctx) {
        private val d = resources.displayMetrics.density
        private var on = false
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.7f * d; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        private val f = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10.5f * d; textAlign = Paint.Align.CENTER }
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        init { isClickable = true; contentDescription = label }
        fun setOn(v: Boolean, newLabel: String?) { on = v; if (newLabel != null) label = newLabel; invalidate() }
        override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((62 * d).toInt(), MeasureSpec.getSize(h))
        override fun onDraw(c: Canvas) {
            val u = d
            if (on) { bg.color = SAND2; c.drawRoundRect(4 * u, 2 * u, width - 4 * u, height - 2 * u, 12 * u, 12 * u, bg) }
            val ink = if (on) BG else TX
            p.color = ink; f.color = ink; tp.color = if (on) BG else MUT
            c.save(); c.translate((width - 24 * u) / 2, 5 * u)
            path.rewind()
            when (kind) {
                Ink.PEN -> {
                    path.moveTo(4 * u, 20 * u); path.lineTo(5.5f * u, 14.5f * u); path.lineTo(15.5f * u, 4.5f * u); path.lineTo(19.5f * u, 8.5f * u); path.lineTo(9.5f * u, 18.5f * u); path.close()
                    path.moveTo(13.5f * u, 6.5f * u); path.lineTo(17.5f * u, 10.5f * u)
                    c.drawPath(path, p); c.drawCircle(7.3f * u, 16.7f * u, 1.1f * u, f)
                }
                Ink.BALL -> {
                    path.moveTo(6 * u, 18 * u); path.lineTo(17 * u, 7 * u)
                    path.moveTo(8 * u, 20 * u); path.lineTo(19 * u, 9 * u); path.lineTo(15 * u, 5 * u); path.lineTo(4 * u, 16 * u); path.lineTo(4 * u, 20 * u); path.close()
                    c.drawPath(path, p)
                }
                Ink.PENCIL -> {
                    path.moveTo(4 * u, 20 * u); path.lineTo(5 * u, 15 * u); path.lineTo(16 * u, 4 * u); path.lineTo(20 * u, 8 * u); path.lineTo(9 * u, 19 * u); path.close()
                    path.moveTo(5 * u, 15 * u); path.lineTo(9 * u, 19 * u)
                    c.drawPath(path, p)
                    path.rewind(); path.moveTo(4 * u, 20 * u); path.lineTo(4.6f * u, 17.2f * u); path.lineTo(6.8f * u, 19.4f * u); path.close(); c.drawPath(path, f)
                }
                Ink.MARKER -> {
                    path.moveTo(6 * u, 15 * u); path.lineTo(15 * u, 6 * u); path.lineTo(19 * u, 10 * u); path.lineTo(10 * u, 19 * u); path.close()
                    path.moveTo(6 * u, 15 * u); path.lineTo(4 * u, 19 * u); path.lineTo(6 * u, 19 * u); path.lineTo(7.5f * u, 17.5f * u)
                    c.drawPath(path, p)
                    f.color = if (on) BG else Color.parseColor("#FFD43B"); c.drawRect(11 * u, 21 * u, 21 * u, 22.6f * u, f)
                }
                InkView.ERASER -> {
                    path.moveTo(8 * u, 20 * u); path.lineTo(3.5f * u, 15.5f * u); path.lineTo(13.5f * u, 5.5f * u); path.lineTo(20.5f * u, 12.5f * u); path.lineTo(13 * u, 20 * u); path.close()
                    path.moveTo(8.5f * u, 10.5f * u); path.lineTo(15.5f * u, 17.5f * u)
                    path.moveTo(13 * u, 20 * u); path.lineTo(21 * u, 20 * u)
                    c.drawPath(path, p)
                }
                InkView.LASSO -> {
                    val dash = p.pathEffect
                    p.pathEffect = DashPathEffect(floatArrayOf(2.6f * u, 2.4f * u), 0f)
                    c.drawOval(3 * u, 3.5f * u, 21 * u, 14.5f * u, p)
                    p.pathEffect = dash
                    path.moveTo(8 * u, 13.5f * u); path.quadTo(6 * u, 18 * u, 9.5f * u, 20.5f * u)
                    c.drawPath(path, p)
                }
            }
            c.restore()
            c.drawText(label, width / 2f, height - 6 * u, tp)
        }
    }

    class Swatch(ctx: Context, val color: Int) : View(ctx) {
        var on = false
        private val d = resources.displayMetrics.density
        private val f = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * d; color = SAND2 }
        private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1f * d }
        init { isClickable = true; contentDescription = Ink.colorHex(color) }
        override fun onDraw(c: Canvas) {
            val cx = width / 2f; val cy = height / 2f
            f.color = color; c.drawCircle(cx, cy, 11 * d, f)
            edge.color = 0x33FFFFFF; c.drawCircle(cx, cy, 11 * d, edge)
            if (on) c.drawCircle(cx, cy, 15 * d, ring)
        }
    }

    /** Shows the current line size and colour. */
    class SizeDot(ctx: Context) : View(ctx) {
        private val d = resources.displayMetrics.density
        private val f = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f * d }
        private var c0 = TX; private var size = 4f; private var hollow = false
        fun set(color: Int, px: Float, outline: Boolean) { c0 = color; size = px; hollow = outline; invalidate() }
        override fun onDraw(c: Canvas) {
            val r = (size / 2).coerceIn(1.5f * d, 15 * d)
            if (hollow) { ring.color = c0; c.drawCircle(width / 2f, height / 2f, r, ring) }
            else { f.color = c0; c.drawCircle(width / 2f, height / 2f, r, f) }
        }
    }
}
