package app.zero.widget

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Handwriting is stored in "page units": the page is always 1000 units wide, so the same
 * note draws at the right size on the tablet, the phone and the Mac. The web app (app.js,
 * drawInk) renders strokes with exactly the same rules as [Ink.draw] below.
 */
object Ink {
    const val PAGE = 1000f

    const val PEN = "pen"        // pressure-sensitive ink
    const val BALL = "ball"      // even ballpoint line
    const val PENCIL = "pencil"  // thin, slightly soft
    const val MARKER = "hl"      // see-through highlighter, drawn under the ink

    /** Width multiplier for the pressure pen; at medium pressure the line is exactly [Stroke.w]. */
    fun penWidth(w: Float, p: Float) = w * (0.4f + 0.8f * p.coerceIn(0f, 1f).pow(0.9f))

    fun alpha(tool: String) = when (tool) { MARKER -> 0.38f; PENCIL -> 0.82f; else -> 1f }

    class Stroke(val tool: String, val color: Int, val w: Float, val pts: FloatArray) {
        /** pts holds x, y, pressure triples in page units. */
        val n get() = pts.size / 3
        val bounds: RectF by lazy {
            val r = RectF(Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE)
            for (i in 0 until n) { val x = pts[i * 3]; val y = pts[i * 3 + 1]; r.left = min(r.left, x); r.top = min(r.top, y); r.right = max(r.right, x); r.bottom = max(r.bottom, y) }
            val pad = w * 1.3f; r.inset(-pad, -pad); r
        }
        fun moved(dx: Float, dy: Float): Stroke {
            val q = pts.copyOf(); for (i in 0 until n) { q[i * 3] += dx; q[i * 3 + 1] += dy }
            return Stroke(tool, color, w, q)
        }
        fun recolored(c: Int) = Stroke(tool, c, w, pts)
        fun slice(from: Int, to: Int) = Stroke(tool, color, w, pts.copyOfRange(from * 3, to * 3))
    }

    /* ---------------- drawing ---------------- */

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()

    /** Draw strokes at [s] pixels per page unit. Highlighter goes first so ink sits on top of it. */
    fun drawAll(c: Canvas, list: List<Stroke>, s: Float, top: Float = -Float.MAX_VALUE, bottom: Float = Float.MAX_VALUE) {
        for (pass in 0..1) for (st in list) {
            if ((st.tool == MARKER) != (pass == 0)) continue
            val b = st.bounds
            if (b.bottom * s < top || b.top * s > bottom) continue
            draw(c, st, s)
        }
    }

    fun draw(c: Canvas, st: Stroke, s: Float, dx: Float = 0f, dy: Float = 0f) {
        val n = st.n; if (n == 0) return
        val p = st.pts
        val col = withAlpha(st.color, alpha(st.tool))
        if (st.tool == PEN) {
            linePaint.color = col
            if (n == 1) { dotPaint.color = col; c.drawCircle((p[0] + dx) * s, (p[1] + dy) * s, penWidth(st.w, p[2]) * s / 2, dotPaint); return }
            // segments sorted into a few width buckets: one drawLines call per bucket
            val buckets = HashMap<Int, FloatArrayBuilder>()
            for (i in 1 until n) {
                val w = penWidth(st.w, (p[i * 3 - 1] + p[i * 3 + 2]) / 2f)
                val key = (w * 4).roundToInt().coerceAtLeast(1)
                buckets.getOrPut(key) { FloatArrayBuilder() }.add(
                    (p[i * 3 - 3] + dx) * s, (p[i * 3 - 2] + dy) * s, (p[i * 3] + dx) * s, (p[i * 3 + 1] + dy) * s)
            }
            for ((k, b) in buckets) { linePaint.strokeWidth = k / 4f * s; c.drawLines(b.a, 0, b.size, linePaint) }
            return
        }
        val w = if (st.tool == PENCIL) st.w * 0.9f else st.w
        if (n == 1) { dotPaint.color = col; c.drawCircle((p[0] + dx) * s, (p[1] + dy) * s, w * s / 2, dotPaint); return }
        smooth(path, p, n, s, dx, dy)
        linePaint.color = col; linePaint.strokeWidth = w * s
        c.drawPath(path, linePaint)
    }

    /** A smooth curve through the points (quadratic segments between midpoints). */
    fun smooth(path: Path, p: FloatArray, n: Int, s: Float, dx: Float = 0f, dy: Float = 0f) {
        path.rewind()
        val x0 = (p[0] + dx) * s; val y0 = (p[1] + dy) * s
        path.moveTo(x0, y0)
        if (n == 2) { path.lineTo((p[3] + dx) * s, (p[4] + dy) * s); return }
        for (i in 1 until n - 1) {
            val cx = (p[i * 3] + dx) * s; val cy = (p[i * 3 + 1] + dy) * s
            val mx = ((p[i * 3] + p[i * 3 + 3]) / 2 + dx) * s; val my = ((p[i * 3 + 1] + p[i * 3 + 4]) / 2 + dy) * s
            path.quadTo(cx, cy, mx, my)
        }
        path.lineTo((p[(n - 1) * 3] + dx) * s, (p[(n - 1) * 3 + 1] + dy) * s)
    }

    fun withAlpha(c: Int, a: Float) = Color.argb((Color.alpha(c) * a).roundToInt(), Color.red(c), Color.green(c), Color.blue(c))

    class FloatArrayBuilder {
        var a = FloatArray(64); var size = 0
        fun add(vararg v: Float) {
            if (size + v.size > a.size) a = a.copyOf(max(a.size * 2, size + v.size))
            for (x in v) a[size++] = x
        }
    }

    /* ---------------- geometry ---------------- */

    /** Distance from point (px,py) to the segment a-b. */
    fun segDist(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val vx = bx - ax; val vy = by - ay
        val len = vx * vx + vy * vy
        val t = if (len == 0f) 0f else (((px - ax) * vx + (py - ay) * vy) / len).coerceIn(0f, 1f)
        return hypot(px - (ax + t * vx), py - (ay + t * vy))
    }

    /** Whole-stroke eraser: drop every stroke the eraser path a-b touches. Returns null when nothing changed. */
    fun eraseStrokes(list: List<Stroke>, ax: Float, ay: Float, bx: Float, by: Float, r: Float): List<Stroke>? {
        var changed = false
        val out = ArrayList<Stroke>(list.size)
        for (st in list) {
            if (touches(st, ax, ay, bx, by, r)) { changed = true; continue }
            out.add(st)
        }
        return if (changed) out else null
    }

    private fun touches(st: Stroke, ax: Float, ay: Float, bx: Float, by: Float, r: Float): Boolean {
        val b = st.bounds
        if (max(ax, bx) + r < b.left || min(ax, bx) - r > b.right || max(ay, by) + r < b.top || min(ay, by) - r > b.bottom) return false
        val rr = r + st.w / 2
        for (i in 0 until st.n) if (segDist(st.pts[i * 3], st.pts[i * 3 + 1], ax, ay, bx, by) <= rr) return true
        return false
    }

    /** Partial eraser: cut the parts of strokes under the eraser path a-b, splitting strokes in two where needed. */
    fun eraseArea(list: List<Stroke>, ax: Float, ay: Float, bx: Float, by: Float, r: Float): List<Stroke>? {
        var changed = false
        val out = ArrayList<Stroke>(list.size + 4)
        for (st in list) {
            if (!touches(st, ax, ay, bx, by, r)) { out.add(st); continue }
            changed = true
            val rr = r + st.w / 2
            var start = -1
            for (i in 0..st.n) {
                val hit = i == st.n || segDist(st.pts[i * 3], st.pts[i * 3 + 1], ax, ay, bx, by) <= rr
                if (!hit && start < 0) start = i
                if (hit && start >= 0) { if (i - start >= 1) out.add(st.slice(start, i)); start = -1 }
            }
        }
        return if (changed) out else null
    }

    fun inPolygon(x: Float, y: Float, poly: FloatArray, n: Int): Boolean {
        var inside = false; var j = n - 1
        for (i in 0 until n) {
            val xi = poly[i * 2]; val yi = poly[i * 2 + 1]; val xj = poly[j * 2]; val yj = poly[j * 2 + 1]
            if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) inside = !inside
            j = i
        }
        return inside
    }

    /** Strokes with most of their points inside the lasso loop. */
    fun lassoPick(list: List<Stroke>, poly: FloatArray, n: Int): Set<Stroke> {
        if (n < 3) return emptySet()
        val out = HashSet<Stroke>()
        for (st in list) {
            var inside = 0
            for (i in 0 until st.n) if (inPolygon(st.pts[i * 3], st.pts[i * 3 + 1], poly, n)) inside++
            if (inside * 2 >= st.n && inside > 0) out.add(st)
        }
        return out
    }

    /* ---------------- storage ---------------- */

    fun colorHex(c: Int) = String.format("#%06X", 0xFFFFFF and c)

    /** Points are stored as whole numbers (x, y at half-unit precision, pressure in %), each one relative to the one before. */
    fun encode(list: List<Stroke>): JSONObject {
        val arr = JSONArray()
        for (st in list) {
            val o = JSONObject()
            o.put("t", st.tool); o.put("c", colorHex(st.color)); o.put("w", (st.w * 10).roundToInt() / 10.0)
            val d = JSONArray()
            var lx = 0; var ly = 0; var lp = 0
            for (i in 0 until st.n) {
                val x = (st.pts[i * 3] * 2).roundToInt(); val y = (st.pts[i * 3 + 1] * 2).roundToInt(); val pr = (st.pts[i * 3 + 2] * 100).roundToInt()
                d.put(x - lx); d.put(y - ly); d.put(pr - lp); lx = x; ly = y; lp = pr
            }
            o.put("p", d)
            arr.put(o)
        }
        return JSONObject().put("v", 1).put("s", arr)
    }

    fun decode(o: JSONObject?): MutableList<Stroke> {
        val out = ArrayList<Stroke>()
        val arr = o?.optJSONArray("s") ?: return out
        for (k in 0 until arr.length()) {
            val so = arr.optJSONObject(k) ?: continue
            val d = so.optJSONArray("p") ?: continue
            val n = d.length() / 3
            val pts = FloatArray(n * 3)
            var x = 0; var y = 0; var pr = 0
            for (i in 0 until n) {
                x += d.optInt(i * 3); y += d.optInt(i * 3 + 1); pr += d.optInt(i * 3 + 2)
                pts[i * 3] = x / 2f; pts[i * 3 + 1] = y / 2f; pts[i * 3 + 2] = pr / 100f
            }
            val color = try { Color.parseColor(so.optString("c", "#ECE6DE")) } catch (e: Exception) { Color.WHITE }
            out.add(Stroke(so.optString("t", PEN), color, so.optDouble("w", 3.0).toFloat(), pts))
        }
        return out
    }

    fun bottom(list: List<Stroke>): Float { var b = 0f; for (st in list) b = max(b, st.bounds.bottom); return b }
}
