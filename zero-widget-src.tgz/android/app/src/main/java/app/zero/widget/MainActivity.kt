package app.zero.widget

import android.Manifest
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity

class MainActivity : ComponentActivity() {

    private val bg = Color.parseColor("#0B0B0C")
    private val card = Color.parseColor("#141416")
    private val tx = Color.parseColor("#EDEDED")
    private val mut = Color.parseColor("#8E8E93")

    private lateinit var calText: TextView
    private lateinit var calBtn: Button
    private lateinit var tasksText: TextView
    private lateinit var tasksBtn: Button
    private lateinit var syncText: TextView

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        refreshUi()
        ZeroWidget.render(this)
    }

    private val authLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        try {
            onAuthorized(Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(r.data))
        } catch (e: Exception) {
            toast("Google sign-in didn't finish")
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun button(label: String, primary: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 15f
        setTextColor(if (primary) bg else tx)
        background = rounded(if (primary) tx else Color.parseColor("#1C1C1F"), 12)
        stateListAnimator = null
        minHeight = dp(48)
        setOnClickListener { onClick() }
    }

    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }

    private fun section(title: String, body: TextView, btn: Button?): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(card, 14)
        setPadding(dp(16), dp(14), dp(16), dp(16))
        addView(text(title, 12f, mut, true).apply { letterSpacing = 0.1f })
        addView(body, lp(6))
        if (btn != null) addView(btn, lp(12))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        calText = text("", 15f, tx)
        calBtn = button("Allow calendar access", true) { permLauncher.launch(Manifest.permission.READ_CALENDAR) }
        tasksText = text("", 15f, tx)
        tasksBtn = button("Connect Google", true) { connect() }
        syncText = text("", 13f, mut)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(56), dp(20), dp(32))
            addView(android.widget.ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.logo)
                adjustViewBounds = true
                contentDescription = "Zerodocs"
            }, LinearLayout.LayoutParams(dp(110), ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(text("Zerodocs control", 28f, tx, true), lp(18))
            addView(text("Today's events and urgent tasks on your home screen.", 15f, mut), lp(6))
            addView(section("CALENDAR", calText, calBtn), lp(24))
            addView(section("TASKS", tasksText, tasksBtn), lp(12))
            addView(button("Add widget to home screen", false) { pinWidget() }, lp(20))
            addView(button("Refresh now", false) { Sync.now(this@MainActivity); ZeroWidget.render(this@MainActivity); toast("Refreshing…") }, lp(10))
            addView(button("Open Zerodocs control", false) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Zero.BASE))) }, lp(10))
            addView(syncText.apply { gravity = Gravity.CENTER }, lp(18))
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(bg); addView(col) })
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
        Sync.schedule(this)
        if (Prefs(this).connected) Sync.now(this)
        ZeroWidget.render(this)
    }

    private fun refreshUi() {
        val p = Prefs(this)
        val cal = Data.hasCalendar(this)
        calText.text = if (cal) "Allowed — events come from your phone's Google Calendar." else "Needed to show today's meetings and events."
        calBtn.visibility = if (cal) View.GONE else View.VISIBLE

        tasksText.text = when {
            !p.connected -> "Connect the Google account you use in Zerodocs control to show your tasks."
            p.needsSignIn -> "Google needs you to sign in again."
            else -> "Connected" + (p.email?.let { " as $it" } ?: "") + "."
        }
        tasksBtn.text = if (p.connected && !p.needsSignIn) "Reconnect" else "Connect Google"
        tasksBtn.visibility = if (p.connected && !p.needsSignIn) View.GONE else View.VISIBLE

        val last = p.lastSync
        syncText.text = buildString {
            append(if (last > 0) "Tasks updated " + DateUtils.getRelativeTimeSpanString(last) else "Tasks not synced yet")
            p.lastError?.let { if (p.connected) append("\n").append(it) }
        }
    }

    private fun connect() {
        Identity.getAuthorizationClient(this)
            .authorize(Drive.request(null))
            .addOnSuccessListener { res ->
                val pi = res.pendingIntent
                if (res.hasResolution() && pi != null) {
                    authLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                } else {
                    onAuthorized(res)
                }
            }
            .addOnFailureListener { e -> toast("Couldn't reach Google: " + (e.message ?: "error")) }
    }

    @Suppress("DEPRECATION")
    private fun onAuthorized(res: AuthorizationResult) {
        val p = Prefs(this)
        p.email = try { res.toGoogleSignInAccount()?.email } catch (e: Exception) { null } ?: p.email
        p.connected = true
        p.needsSignIn = false
        p.fileId = null
        Sync.now(this)
        refreshUi()
        toast("Connected")
    }

    private fun pinWidget() {
        val mgr = AppWidgetManager.getInstance(this)
        if (mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, ZeroWidget::class.java), null, null)
        } else {
            toast("Long-press your home screen › Widgets › Zerodocs control")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
