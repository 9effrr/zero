package app.zero.widget

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** Invisible hop: widget taps land here, then open the app at the right place (?v=… ?a=… ?t=…). */
class OpenActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val q = intent?.data?.encodedQuery ?: ""
        startActivity(
            Intent(this, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_QUERY, q)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
        finish()
    }
}
