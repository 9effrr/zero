package app.zero.widget

import android.graphics.Typeface
import android.text.Editable
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextPaint
import android.text.style.MetricAffectingSpan
import android.text.style.StyleSpan
import android.widget.EditText

/**
 * Formatted note text, shared with the web app (app.js richParse / richOut):
 * <h1>, <h2>, <p> blocks holding <b>bold</b> and <span class="l">light</span> runs.
 */
object RichText {

    open class BlockSpan(val tag: String, private val scale: Float) : MetricAffectingSpan() {
        override fun updateDrawState(tp: TextPaint) = apply(tp)
        override fun updateMeasureState(tp: TextPaint) = apply(tp)
        private fun apply(tp: TextPaint) { tp.textSize *= scale; tp.typeface = Typeface.create(tp.typeface, Typeface.BOLD) }
    }
    class H1 : BlockSpan("h1", 1.5f)
    class H2 : BlockSpan("h2", 1.2f)

    class Light : MetricAffectingSpan() {
        private val tf = Typeface.create("sans-serif-light", Typeface.NORMAL)
        override fun updateDrawState(tp: TextPaint) { tp.typeface = tf }
        override fun updateMeasureState(tp: TextPaint) { tp.typeface = tf }
    }

    private fun isBold(o: Any) = o is StyleSpan && o.style == Typeface.BOLD

    /* ---------- editing ---------- */

    private fun paraStart(s: CharSequence, i: Int): Int { var p = i.coerceIn(0, s.length); while (p > 0 && s[p - 1] != '\n') p--; return p }
    private fun paraEnd(s: CharSequence, i: Int): Int { var p = i.coerceIn(0, s.length); while (p < s.length && s[p] != '\n') p++; return p }

    /** Make the paragraphs under the cursor H1, H2 or plain text ("p"). */
    fun setBlock(e: EditText, tag: String) {
        val s = e.text ?: return
        val a = paraStart(s, minOf(e.selectionStart, e.selectionEnd)); val b = paraEnd(s, maxOf(e.selectionStart, e.selectionEnd))
        var p = a
        while (p <= b) {
            val end = paraEnd(s, p)
            for (sp in s.getSpans(p, end, BlockSpan::class.java)) { val st = s.getSpanStart(sp); if (st in p..end) s.removeSpan(sp) }
            when (tag) {
                "h1" -> s.setSpan(H1(), p, end, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
                "h2" -> s.setSpan(H2(), p, end, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
            }
            p = end + 1
        }
        e.invalidate(); e.requestLayout()
    }

    /* Writing direction per paragraph. Android already picks each paragraph's direction from its first
       letter (Arabic right, English left); a forced direction is kept as an invisible RLM / LRM mark at the
       paragraph start, which the layout reads, and which is stored as dir="rtl" / dir="ltr" on the block. */
    const val RLM = '\u200F'
    const val LRM = '\u200E'
    private fun isMark(c: Char) = c == RLM || c == LRM

    /** "auto", "ltr" or "rtl" for the paragraphs under the cursor. */
    fun setDir(e: EditText, d: String) {
        val s = e.text ?: return
        val a = paraStart(s, minOf(e.selectionStart, e.selectionEnd)); val b = paraEnd(s, maxOf(e.selectionStart, e.selectionEnd))
        val starts = ArrayList<Int>()
        var p = a
        while (p <= b && p <= s.length) { starts.add(p); val end = paraEnd(s, p); if (end >= s.length) break; p = end + 1 }
        for (st in starts.reversed()) {
            while (st < s.length && isMark(s[st])) s.delete(st, st + 1)
            when (d) { "rtl" -> s.insert(st, RLM.toString()); "ltr" -> s.insert(st, LRM.toString()) }
        }
        e.invalidate(); e.requestLayout()
    }

    /** One button, like Google Docs: flips the paragraphs under the cursor between right-to-left and left-to-right.
        Returns the direction they now have. */
    fun toggleDir(e: EditText): String {
        val s = e.text ?: return "ltr"
        val at = minOf(e.selectionStart, e.selectionEnd).coerceIn(0, s.length)
        val cur = when (dirAt(s, at)) {
            "rtl" -> true
            "ltr" -> false
            else -> try { val l = e.layout; l != null && l.getParagraphDirection(l.getLineForOffset(at)) == android.text.Layout.DIR_RIGHT_TO_LEFT } catch (x: Exception) { false }
        }
        val next = if (cur) "ltr" else "rtl"
        setDir(e, next)
        return next
    }

    /** The direction the paragraph at the cursor is shown in (forced or found from its first letter). */
    fun shownDir(e: EditText): String {
        val s = e.text ?: return "ltr"
        val at = minOf(e.selectionStart, e.selectionEnd).coerceIn(0, s.length)
        return when (dirAt(s, at)) {
            "rtl" -> "rtl"; "ltr" -> "ltr"
            else -> try { val l = e.layout; if (l != null && l.getParagraphDirection(l.getLineForOffset(at)) == android.text.Layout.DIR_RIGHT_TO_LEFT) "rtl" else "ltr" } catch (x: Exception) { "ltr" }
        }
    }

    /** Direction of the paragraph at the cursor. */
    fun dirAt(s: CharSequence, i: Int): String {
        val p = paraStart(s, i)
        return if (p < s.length && s[p] == RLM) "rtl" else if (p < s.length && s[p] == LRM) "ltr" else "auto"
    }

    /** Call from a TextWatcher: a new line keeps the direction of the paragraph it was split from. */
    fun carryDir(s: Editable, start: Int, count: Int) {
        if (count != 1 || start >= s.length || s[start] != '\n') return
        val ps = paraStart(s, start)
        if (ps < s.length && isMark(s[ps]) && (start + 1 >= s.length || !isMark(s[start + 1]))) s.insert(start + 1, s[ps].toString())
    }

    var pending: String? = null

    /** Bold, regular or light for the selection; with no selection, the word under the cursor (or what you type next). */
    fun setWeight(e: EditText, w: String) {
        val s = e.text ?: return
        var a = minOf(e.selectionStart, e.selectionEnd); var b = maxOf(e.selectionStart, e.selectionEnd)
        if (a == b) {
            var x = a; var y = b
            while (x > 0 && !s[x - 1].isWhitespace()) x--
            while (y < s.length && !s[y].isWhitespace()) y++
            if (x == y) { pending = w; return }
            a = x; b = y
        }
        weightRange(s, a, b, w)
        e.invalidate()
    }

    private fun weightRange(s: Editable, a: Int, b: Int, w: String) {
        for (sp in s.getSpans(a, b, Any::class.java)) {
            if (!isBold(sp) && sp !is Light) continue
            val st = s.getSpanStart(sp); val en = s.getSpanEnd(sp)
            if (en <= a || st >= b) continue
            s.removeSpan(sp)
            if (st < a) s.setSpan(if (sp is Light) Light() else StyleSpan(Typeface.BOLD), st, a, Spanned.SPAN_EXCLUSIVE_INCLUSIVE)
            if (en > b) s.setSpan(if (sp is Light) Light() else StyleSpan(Typeface.BOLD), b, en, Spanned.SPAN_EXCLUSIVE_INCLUSIVE)
        }
        when (w) {
            "bold" -> s.setSpan(StyleSpan(Typeface.BOLD), a, b, Spanned.SPAN_EXCLUSIVE_INCLUSIVE)
            "light" -> s.setSpan(Light(), a, b, Spanned.SPAN_EXCLUSIVE_INCLUSIVE)
        }
    }

    /** Call from a TextWatcher: applies a pending weight to what was just typed. */
    fun typed(s: Editable, start: Int, count: Int) {
        val w = pending ?: return
        pending = null
        if (count > 0) weightRange(s, start, start + count, w)
    }

    /** Keep headings to one paragraph: pressing Enter at the end of a heading starts plain text. */
    fun tidy(s: Editable) {
        for (sp in s.getSpans(0, s.length, BlockSpan::class.java)) {
            val st = s.getSpanStart(sp); val en = s.getSpanEnd(sp)
            val pe = paraEnd(s, st)
            if (en > pe) { s.removeSpan(sp); s.setSpan(if (sp is H1) H1() else H2(), st, pe, Spanned.SPAN_INCLUSIVE_INCLUSIVE) }
        }
    }

    /* ---------- storage ---------- */

    private fun esc(t: CharSequence) = buildString { for (c in t) when (c) { '&' -> append("&amp;"); '<' -> append("&lt;"); '>' -> append("&gt;"); '"' -> append("&quot;"); else -> append(c) } }

    fun toHtml(s: Spanned): String {
        val out = StringBuilder()
        var p = 0
        while (true) {
            val end = paraEnd(s, p)
            val blk = s.getSpans(p, end, BlockSpan::class.java).firstOrNull { s.getSpanStart(it) in p..end }
            val tag = blk?.tag ?: "p"
            out.append('<').append(tag)
            if (p < end && s[p] == RLM) out.append(" dir=\"rtl\"") else if (p < end && s[p] == LRM) out.append(" dir=\"ltr\"")
            out.append('>')
            val cuts = sortedSetOf(p, end)
            val inl = s.getSpans(p, end, Any::class.java).filter { isBold(it) || it is Light }
            for (sp in inl) { cuts.add(s.getSpanStart(sp).coerceIn(p, end)); cuts.add(s.getSpanEnd(sp).coerceIn(p, end)) }
            val list = cuts.toList()
            for (i in 0 until list.size - 1) {
                val a = list[i]; val b = list[i + 1]; if (a >= b) continue
                val bold = inl.any { isBold(it) && s.getSpanStart(it) <= a && s.getSpanEnd(it) >= b }
                val light = !bold && inl.any { it is Light && s.getSpanStart(it) <= a && s.getSpanEnd(it) >= b }
                val t = esc(s.subSequence(a, b).filterNot { isMark(it) })
                when { bold -> out.append("<b>").append(t).append("</b>"); light -> out.append("<span class=\"l\">").append(t).append("</span>"); else -> out.append(t) }
            }
            out.append("</").append(tag).append('>')
            if (end >= s.length) break
            p = end + 1
        }
        return out.toString()
    }

    private val TAG = Regex("<\\s*(/?)\\s*([a-zA-Z0-9]+)([^>]*)>")

    private fun unesc(t: String) = t.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'").replace("&nbsp;", " ").replace("&amp;", "&")

    fun fromHtml(html: String): SpannableStringBuilder {
        val sb = SpannableStringBuilder()
        var started = false
        var blockTag = "p"; var blockStart = 0
        val stack = ArrayList<Pair<String, Int>>() // inline kind ("b", "l" or "") + start
        fun closeBlock() {
            if (blockTag == "h1") sb.setSpan(H1(), blockStart, sb.length, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
            else if (blockTag == "h2") sb.setSpan(H2(), blockStart, sb.length, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
            blockTag = "p"
        }
        fun openBlock(tag: String, dir: String = "") {
            if (started) sb.append('\n')
            started = true; blockTag = tag; blockStart = sb.length
            if (dir == "rtl") sb.append(RLM) else if (dir == "ltr") sb.append(LRM)
        }
        var i = 0
        for (m in TAG.findAll(html)) {
            if (m.range.first > i) { val t = unesc(html.substring(i, m.range.first)); if (t.isNotEmpty()) { if (!started) { started = true; blockStart = 0 }; sb.append(t) } }
            i = m.range.last + 1
            val closing = m.groupValues[1] == "/"; val tag = m.groupValues[2].lowercase(); val attrs = m.groupValues[3]
            when (tag) {
                "h1", "h2", "h3", "p", "div", "li" -> if (!closing) openBlock(if (tag == "h1") "h1" else if (tag == "p" || tag == "div" || tag == "li") "p" else "h2",
                    Regex("dir\\s*=\\s*\"?(rtl|ltr)", RegexOption.IGNORE_CASE).find(attrs)?.groupValues?.get(1)?.lowercase() ?: "") else closeBlock()
                "br" -> { closeBlock(); openBlock("p") }
                "b", "strong", "span" -> {
                    if (!closing) stack.add((if (tag == "span") (if (Regex("class\\s*=\\s*\"?l\"?").containsMatchIn(attrs)) "l" else "") else "b") to sb.length)
                    else if (stack.isNotEmpty()) {
                        val (k, st) = stack.removeAt(stack.size - 1)
                        if (sb.length > st) when (k) {
                            "b" -> sb.setSpan(StyleSpan(Typeface.BOLD), st, sb.length, Spanned.SPAN_EXCLUSIVE_INCLUSIVE)
                            "l" -> sb.setSpan(Light(), st, sb.length, Spanned.SPAN_EXCLUSIVE_INCLUSIVE)
                        }
                    }
                }
            }
        }
        if (i < html.length) sb.append(unesc(html.substring(i)))
        closeBlock()
        return sb
    }

    fun plain(s: CharSequence) = s.toString().filterNot { isMark(it) }

    @Suppress("unused") private fun keep(s: Spannable) = s
}
