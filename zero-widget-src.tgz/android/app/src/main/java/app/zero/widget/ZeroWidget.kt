package app.zero.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.RemoteViews
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.concurrent.TimeUnit

class ZeroWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        render(ctx)
        Sync.schedule(ctx)
    }

    override fun onEnabled(ctx: Context) {
        Sync.schedule(ctx)
        Sync.now(ctx)
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, mgr: AppWidgetManager, id: Int, opts: Bundle) {
        render(ctx)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action == ACTION_REFRESH) {
            render(ctx)
            Sync.now(ctx)
        }
    }

    companion object {
        const val ACTION_REFRESH = "app.zero.widget.REFRESH"

        private fun open(ctx: Context, code: Int, url: String): PendingIntent =
            PendingIntent.getActivity(
                ctx, code,
                Intent(ctx, OpenActivity::class.java).setData(Uri.parse(url)),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        private fun refreshIntent(ctx: Context, code: Int): PendingIntent =
            PendingIntent.getBroadcast(
                ctx, code,
                Intent(ctx, ZeroWidget::class.java).setAction(ACTION_REFRESH),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        fun render(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, ZeroWidget::class.java))
            if (ids.isEmpty()) return

            val p = Prefs(ctx)
            val events = Data.todayEvents(ctx)
            val tasks = if (p.connected) Data.tasks(ctx) else null
            val rows = (events ?: emptyList()) + (tasks ?: emptyList())

            val rv = RemoteViews(ctx.packageName, R.layout.widget)

            val items = RemoteViews.RemoteCollectionItems.Builder()
                .setHasStableIds(false)
                .setViewTypeCount(1)
            rows.forEachIndexed { i, r ->
                val row = RemoteViews(ctx.packageName, R.layout.widget_row)
                row.setTextViewText(R.id.rt, r.title)
                row.setTextViewText(R.id.rm, r.meta)
                row.setViewVisibility(R.id.rm, if (r.meta.isEmpty()) View.GONE else View.VISIBLE)
                row.setInt(R.id.bar, "setColorFilter", r.color)
                row.setOnClickFillInIntent(R.id.row, Intent().setData(Uri.parse(r.url)))
                items.addItem(i.toLong(), row)
            }
            rv.setRemoteAdapter(R.id.list, items.build())
            rv.setEmptyView(R.id.list, R.id.empty)
            rv.setPendingIntentTemplate(
                R.id.list,
                PendingIntent.getActivity(
                    ctx, 1, Intent(ctx, OpenActivity::class.java),
                    PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )

            val setup = PendingIntent.getActivity(
                ctx, 5, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val status = when {
                events == null -> "Allow calendar access · tap"
                !p.connected || p.needsSignIn -> "Connect Google to show tasks · tap"
                tasks == null -> "Loading tasks…"
                else -> ""
            }
            rv.setTextViewText(R.id.status, status)
            rv.setViewVisibility(R.id.status, if (status.isEmpty()) View.GONE else View.VISIBLE)
            rv.setOnClickPendingIntent(R.id.status, setup)

            rv.setTextViewText(R.id.empty, if (events == null && tasks == null) "Tap to set up" else "Nothing today")
            rv.setOnClickPendingIntent(R.id.empty, if (events == null && tasks == null) setup else open(ctx, 6, Zero.BASE + "?v=home"))

            rv.setOnClickPendingIntent(R.id.title, open(ctx, 2, Zero.BASE + "?v=home"))
            rv.setOnClickPendingIntent(R.id.logo, open(ctx, 8, Zero.BASE + "?v=home"))
            rv.setOnClickPendingIntent(R.id.add, open(ctx, 3, Zero.BASE + "?a=add"))
            rv.setOnClickPendingIntent(R.id.refresh, refreshIntent(ctx, 4))

            mgr.updateAppWidget(ids, rv)
            scheduleMidnight(ctx)
        }

        /** Re-render just after midnight so the list switches to the new day. */
        private fun scheduleMidnight(ctx: Context) {
            val next = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 1); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val am = ctx.getSystemService(AlarmManager::class.java) ?: return
            am.set(AlarmManager.RTC, next.timeInMillis, refreshIntent(ctx, 7))
        }
    }
}

class SyncWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            Drive.refresh(applicationContext)
        } catch (e: Exception) {
            Prefs(applicationContext).lastError = e.javaClass.simpleName + ": " + (e.message ?: "")
        }
        ZeroWidget.render(applicationContext)
        Result.success()
    }
}

object Sync {
    private val online = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

    fun schedule(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<SyncWorker>(30, TimeUnit.MINUTES).setConstraints(online).build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("zero-periodic", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    fun now(ctx: Context) {
        val req = OneTimeWorkRequestBuilder<SyncWorker>().setConstraints(online).build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("zero-now", ExistingWorkPolicy.REPLACE, req)
    }
}
