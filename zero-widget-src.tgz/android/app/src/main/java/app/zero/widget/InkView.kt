package app.zero.widget

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.RenderNode
import android.os.Build
import android.os.SystemClock
import android.view.MotionEvent
import android.view.MotionPredictor
import android.view.View
import android.widget.ScrollView
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * The handwriting layer. It lies over the whole note page (typed text underneath) and,
 * in pen mode, takes every touch: the S Pen draws, fingers scroll, and a resting palm is ignored.
 */
@SuppressLint("ViewConstructor")
class InkView(ctx: Context, private val scroller: () -> ScrollView?) : View(ctx) {

    interface Host {
        fun inkChanged()
        fun selectionChanged(count: Int)
        fun historyChanged(canUndo: Boolean, canRedo: Boolean)
        fun minPageHeight(): Int
    }

    var host: Host? = null

    /* ---- state ---- */
    var strokes: List<Ink.Stroke> = emptyList(); private set
    private val undo = ArrayList<List<Ink.Stroke>>()
    private val redo = ArrayList<List<Ink.Stroke>>()

    /** pixels per page unit */
    var scale = 1f
        set(v) { if (v != field) { field = v; dirty(); requestLayout() } }

    var penMode = true
        set(v) { field = v; if (!v) { cancelGesture(); clearSelection() }; invalidate() }
    var fingerDraws = false

    var tool = Ink.PEN
        set(v) { if (field != v) { field = v; if (v != LASSO) clearSelection(); invalidate() } }
    var color = Color.parseColor("#ECE6DE")
    var penWidth = 3f
    var eraserSize = 14f
    var eraseWhole = true

    companion object {
        const val ERASER = "eraser"
        const val LASSO = "lasso"
    }

    fun load(list: List<Ink.Stroke>) { strokes = list; undo.clear(); redo.clear(); notifyHistory(); dirty(); requestLayout() }

    /* ---- drawing cache: committed strokes recorded once, replayed every frame ---- */
    private val node = RenderNode("ink")
    private var nodeOk = false
    private var nodeTop = 0f
    private var nodeBottom = 0f
    private val vis = Rect()

    /* strokes added since the big recording live in a small second recording, so lifting the pen
       doesn't replay the whole page (that was the hitch after each stroke on long notes) */
    private val tailNode = RenderNode("ink-tail")
    private var baseCount = 0
    private var tailOk = false

    private fun dirty() { nodeOk = false; tailOk = false; invalidate() }

    /** true while the pen (or a finger gesture) is on the page, so saving can wait */
    fun busy() = live != null || gesture in 1..5

    private fun commit(next: List<Ink.Stroke>, record: Boolean = true) {
        if (record) { undo.add(strokes); if (undo.size > 80) undo.removeAt(0); redo.clear() }
        val appended = nodeOk && selected.isEmpty() && next.size == strokes.size + 1 && baseCount <= strokes.size &&
            (strokes.isEmpty() || next[strokes.size - 1] === strokes[strokes.size - 1])
        strokes = next
        notifyHistory()
        if (appended) { tailOk = false; invalidate() } else dirty()
        host?.inkChanged()
        if ((Ink.bottom(strokes) * scale).toInt() + 200 > height) requestLayout()
    }

    fun undo() {
        if (undo.isEmpty()) return
        clearSelection(); redo.add(strokes); strokes = undo.removeAt(undo.size - 1)
        notifyHistory(); dirty(); host?.inkChanged()
    }

    fun redo() {
        if (redo.isEmpty()) return
        clearSelection(); undo.add(strokes); strokes = redo.removeAt(redo.size - 1)
        notifyHistory(); dirty(); host?.inkChanged()
    }

    private fun notifyHistory() = host?.historyChanged(undo.isNotEmpty(), redo.isNotEmpty())

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val viewport = scroller()?.height ?: 0
        val inkBottom = (Ink.bottom(strokes) * scale).toInt()
        val h = max(host?.minPageHeight() ?: 0, inkBottom) + max(viewport, 600)
        setMeasuredDimension(w, h)
    }

    /* ---- paints ---- */
    private val dp = resources.displayMetrics.density
    private val lassoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.6f * dp; color = Color.parseColor("#DDBF9F")
        pathEffect = DashPathEffect(floatArrayOf(7 * dp, 6 * dp), 0f)
    }
    private val selFill = Paint().apply { color = Color.argb(28, 221, 191, 159) }
    private val cursorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f * dp; color = Color.argb(170, 236, 230, 222) }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lassoPath = Path()

    override fun onDraw(c: Canvas) {
        getLocalVisibleRect(vis)
        val s = scale
        val margin = max(vis.height(), 400).toFloat()
        if (c.isHardwareAccelerated) {
            if (!nodeOk || vis.top < nodeTop || vis.bottom > nodeBottom || baseCount > strokes.size || strokes.size - baseCount > 40) {
                nodeTop = vis.top - margin; nodeBottom = vis.bottom + margin
                node.setPosition(0, 0, width, height)
                val rc = node.beginRecording()
                Ink.drawAll(rc, if (selected.isEmpty()) strokes else strokes.filter { it !in selected }, s, nodeTop, nodeBottom)
                node.endRecording()
                nodeOk = true; baseCount = strokes.size; tailOk = false
            }
            c.drawRenderNode(node)
            if (strokes.size > baseCount) {
                if (!tailOk) {
                    tailNode.setPosition(0, 0, width, height)
                    val tc = tailNode.beginRecording()
                    Ink.drawAll(tc, strokes.subList(baseCount, strokes.size), s)
                    tailNode.endRecording()
                    tailOk = true
                }
                c.drawRenderNode(tailNode)
            }
        } else {
            Ink.drawAll(c, if (selected.isEmpty()) strokes else strokes.filter { it !in selected }, s, vis.top - margin, vis.bottom + margin)
        }

        // the selection, possibly being dragged
        if (selected.isNotEmpty()) {
            for (st in selected) Ink.draw(c, st, s, dragDx, dragDy)
            val r = selBounds()
            c.drawRoundRect((r.left + dragDx) * s, (r.top + dragDy) * s, (r.right + dragDx) * s, (r.bottom + dragDy) * s, 8 * dp, 8 * dp, selFill)
            c.drawRoundRect((r.left + dragDx) * s, (r.top + dragDy) * s, (r.right + dragDx) * s, (r.bottom + dragDy) * s, 8 * dp, 8 * dp, lassoPaint)
        }

        // the stroke being written right now, plus the predicted next few millimetres
        live?.let { b ->
            val st = Ink.Stroke(liveTool, liveColor, liveWidth, b.a.copyOf(b.size))
            Ink.draw(c, st, s)
            predicted?.let { pr ->
                if (st.n > 0 && liveTool != Ink.MARKER) {
                    val last = st.n - 1
                    val tail = floatArrayOf(st.pts[last * 3], st.pts[last * 3 + 1], st.pts[last * 3 + 2], pr[0], pr[1], pr[2])
                    Ink.draw(c, Ink.Stroke(liveTool, liveColor, liveWidth, tail), s)
                }
            }
        }

        if (lassoN > 1) {
            Ink.smooth(lassoPath, lassoPts.a.let { a -> FloatArray(lassoN * 3) { i -> if (i % 3 == 2) 0f else a[(i / 3) * 2 + i % 3] } }, lassoN, s)
            c.drawPath(lassoPath, lassoPaint)
        }

        // a ring under the S Pen while it hovers (shows the eraser size, or where ink will land)
        if (hoverX >= 0 && penMode) {
            val r = if (effectiveTool() == ERASER) eraserSize * s else max(1.5f * dp, penWidth * s / 2)
            if (effectiveTool() == ERASER || tool == LASSO) c.drawCircle(hoverX, hoverY, r, cursorPaint)
            else { dotPaint.color = Ink.withAlpha(color, 0.55f); c.drawCircle(hoverX, hoverY, r, dotPaint) }
        }
    }

    /* ---- input ---- */
    private var live: Ink.FloatArrayBuilder? = null
    private var liveTool = Ink.PEN
    private var liveColor = 0
    private var liveWidth = 3f
    private var predicted: FloatArray? = null
    private var drawPointer = -1
    private var gesture = 0 // 0 none, 1 drawing, 2 scrolling, 3 erasing, 4 lasso, 5 moving selection, 9 ignore (palm)
    private var lastStylus = 0L
    private var hoverX = -1f
    private var hoverY = -1f
    private var buttonErase = false
    private var lastEx = 0f
    private var lastEy = 0f
    private var eraseBefore: List<Ink.Stroke>? = null

    private val predictor: MotionPredictor? = if (Build.VERSION.SDK_INT >= 34) try { MotionPredictor(ctx) } catch (e: Throwable) { null } else null

    private fun effectiveTool() = if (buttonErase) ERASER else tool

    private fun isPen(e: MotionEvent, i: Int): Boolean {
        val t = e.getToolType(i)
        return t == MotionEvent.TOOL_TYPE_STYLUS || t == MotionEvent.TOOL_TYPE_ERASER
    }

    override fun onHoverEvent(e: MotionEvent): Boolean {
        if (!penMode || !isPen(e, 0)) return super.onHoverEvent(e)
        lastStylus = SystemClock.uptimeMillis()
        when (e.actionMasked) {
            MotionEvent.ACTION_HOVER_EXIT -> { hoverX = -1f }
            else -> { hoverX = e.x; hoverY = e.y; buttonErase = e.buttonState and MotionEvent.BUTTON_STYLUS_PRIMARY != 0 || e.getToolType(0) == MotionEvent.TOOL_TYPE_ERASER }
        }
        invalidate()
        return true
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!penMode) return false
        val act = e.actionMasked

        // Find the S Pen in this event, if it is part of it.
        var pen = -1
        for (i in 0 until e.pointerCount) if (isPen(e, i)) { pen = i; break }

        if (pen >= 0) {
            lastStylus = SystemClock.uptimeMillis()
            val id = e.getPointerId(pen)
            val down = act == MotionEvent.ACTION_DOWN || (act == MotionEvent.ACTION_POINTER_DOWN && e.actionIndex == pen)
            if (down) {
                // The pen wins over anything a palm or finger started.
                if (gesture == 2) stopScroll()
                cancelGesture()
                requestUnbufferedDispatch(e)
                parent?.requestDisallowInterceptTouchEvent(true)
                drawPointer = id
                hoverX = -1f
                buttonErase = e.buttonState and MotionEvent.BUTTON_STYLUS_PRIMARY != 0 || e.getToolType(pen) == MotionEvent.TOOL_TYPE_ERASER
                begin(e, pen)
                return true
            }
            if (id == drawPointer) {
                val up = act == MotionEvent.ACTION_UP || (act == MotionEvent.ACTION_POINTER_UP && e.actionIndex == pen)
                when {
                    act == MotionEvent.ACTION_CANCEL -> cancelGesture()
                    up -> { move(e, pen); end() }
                    act == MotionEvent.ACTION_MOVE -> move(e, pen)
                }
                return true
            }
            return true
        }

        // Only fingers / palm from here on.
        if (gesture in 1..5 && drawPointer >= 0 && !fingerGesture) return true // a pen gesture is in progress: ignore palms
        if (act == MotionEvent.ACTION_CANCEL || (e.flags and MotionEvent.FLAG_CANCELED) != 0) { if (fingerGesture) cancelGesture(); stopScroll(); return true }

        if (act == MotionEvent.ACTION_DOWN) {
            fingerGesture = false
            val palm = SystemClock.uptimeMillis() - lastStylus < 600 || e.getTouchMajor(0) > 42 * dp
            if (palm) { gesture = 9; return true }
            if (fingerDraws || (selected.isNotEmpty() && hitSelection(e.x, e.y))) {
                fingerGesture = true; drawPointer = e.getPointerId(0); begin(e, 0); return true
            }
            startScroll(e); return true
        }
        if (gesture == 9) {
            if (act == MotionEvent.ACTION_UP) gesture = 0
            return true
        }
        if (fingerGesture) {
            when (act) {
                MotionEvent.ACTION_POINTER_DOWN -> { // a second finger turns finger-drawing into scrolling
                    if (gesture == 1 && (live?.size ?: 0) < 12) { live = null; gesture = 0; fingerGesture = false; startScroll(e) }
                }
                MotionEvent.ACTION_MOVE -> { val i = e.findPointerIndex(drawPointer); if (i >= 0) move(e, i) }
                MotionEvent.ACTION_UP -> { val i = e.findPointerIndex(drawPointer); if (i >= 0) move(e, i); end(); fingerGesture = false }
            }
            if (fingerGesture || gesture != 2) return true
        }
        if (gesture == 2) scrollTouch(e)
        return true
    }

    private var fingerGesture = false

    private fun cancelGesture() {
        if (gesture == 3) eraseBefore = null
        live = null; predicted = null; lassoN = 0; dragDx = 0f; dragDy = 0f
        if (gesture == 5) invalidate()
        gesture = 0; drawPointer = -1; fingerGesture = false
        invalidate()
    }

    private fun ux(x: Float) = x / scale
    private fun uy(y: Float) = y / scale

    private fun begin(e: MotionEvent, i: Int) {
        val x = ux(e.getX(i)); val y = uy(e.getY(i))
        val t = effectiveTool()
        when {
            selected.isNotEmpty() && hitSelection(e.getX(i), e.getY(i)) -> { gesture = 5; dragX = x; dragY = y }
            t == ERASER -> { gesture = 3; eraseBefore = strokes; lastEx = x; lastEy = y; eraseAt(x, y) }
            t == LASSO -> { clearSelection(); gesture = 4; lassoN = 0; lassoPts.size = 0; addLasso(x, y) }
            else -> {
                if (selected.isNotEmpty()) clearSelection()
                gesture = 1
                liveTool = t; liveColor = color; liveWidth = penWidth
                live = Ink.FloatArrayBuilder().also { it.add(x, y, pressure(e, i, -1)) }
                predictor?.record(e)
            }
        }
        invalidate()
    }

    private fun pressure(e: MotionEvent, i: Int, h: Int): Float {
        val tt = e.getToolType(i)
        if (tt != MotionEvent.TOOL_TYPE_STYLUS && tt != MotionEvent.TOOL_TYPE_ERASER) return 0.5f
        return (if (h < 0) e.getPressure(i) else e.getHistoricalPressure(i, h)).coerceIn(0f, 1f)
    }

    private fun move(e: MotionEvent, i: Int) {
        when (gesture) {
            1 -> {
                val b = live ?: return
                for (h in 0 until e.historySize) addPoint(b, ux(e.getHistoricalX(i, h)), uy(e.getHistoricalY(i, h)), pressure(e, i, h))
                addPoint(b, ux(e.getX(i)), uy(e.getY(i)), pressure(e, i, -1))
                predicted = null
                predictor?.let { p ->
                    p.record(e)
                    try {
                        val pe = p.predict(e.eventTime * 1_000_000L + 12_000_000L)
                        if (pe != null) {
                            val pi = (0 until pe.pointerCount).firstOrNull { pe.getPointerId(it) == e.getPointerId(i) } ?: 0
                            predicted = floatArrayOf(ux(pe.getX(pi)), uy(pe.getY(pi)), b.a[b.size - 1])
                            pe.recycle()
                        }
                    } catch (_: Throwable) { }
                }
                invalidate()
            }
            3 -> {
                for (h in 0 until e.historySize) eraseAt(ux(e.getHistoricalX(i, h)), uy(e.getHistoricalY(i, h)))
                eraseAt(ux(e.getX(i)), uy(e.getY(i)))
            }
            4 -> { addLasso(ux(e.getX(i)), uy(e.getY(i))); invalidate() }
            5 -> { dragDx = ux(e.getX(i)) - dragX; dragDy = uy(e.getY(i)) - dragY; invalidate() }
        }
    }


    private fun addPoint(b: Ink.FloatArrayBuilder, x: Float, y: Float, p: Float) {
        val n = b.size
        if (n >= 3 && hypot(x - b.a[n - 3], y - b.a[n - 2]) < 0.6f) { b.a[n - 1] = max(b.a[n - 1], p); return }
        b.add(x, y, p)
    }

    private fun end() {
        when (gesture) {
            1 -> {
                val b = live
                live = null; predicted = null
                if (b != null && b.size >= 3) commit(strokes + Ink.Stroke(liveTool, liveColor, liveWidth, b.a.copyOf(b.size)))
            }
            3 -> {
                val before = eraseBefore
                if (before != null && before !== strokes) { undo.add(before); if (undo.size > 80) undo.removeAt(0); redo.clear(); notifyHistory(); host?.inkChanged() }
                eraseBefore = null
            }
            4 -> {
                val pick = Ink.lassoPick(strokes, lassoPts.a, lassoN)
                lassoN = 0
                if (pick.isNotEmpty()) { selected = pick; dirty(); host?.selectionChanged(pick.size) }
            }
            5 -> {
                if (abs(dragDx) > 0.5f || abs(dragDy) > 0.5f) {
                    val moved = HashSet<Ink.Stroke>()
                    val next = strokes.map { if (it in selected) it.moved(dragDx, dragDy).also { m -> moved.add(m) } else it }
                    dragDx = 0f; dragDy = 0f
                    commit(next); selected = moved; dirty()
                }
                dragDx = 0f; dragDy = 0f
            }
        }
        gesture = 0; drawPointer = -1
        invalidate()
    }

    private fun eraseAt(x: Float, y: Float) {
        val r = eraserSize
        val next = if (eraseWhole) Ink.eraseStrokes(strokes, lastEx, lastEy, x, y, r) else Ink.eraseArea(strokes, lastEx, lastEy, x, y, r)
        lastEx = x; lastEy = y
        hoverX = x * scale; hoverY = y * scale
        if (next != null) { strokes = next; dirty() } else invalidate()
    }

    /* ---- lasso & selection ---- */
    private val lassoPts = Ink.FloatArrayBuilder()
    private var lassoN = 0
    private var selected: Set<Ink.Stroke> = emptySet()
    private var dragX = 0f
    private var dragY = 0f
    private var dragDx = 0f
    private var dragDy = 0f

    private fun addLasso(x: Float, y: Float) { lassoPts.add(x, y); lassoN++ }

    private fun selBounds(): RectF {
        val r = RectF(Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE)
        for (st in selected) r.union(st.bounds)
        return r
    }

    private fun hitSelection(px: Float, py: Float): Boolean {
        if (selected.isEmpty()) return false
        val r = selBounds(); val x = px / scale; val y = py / scale
        return x >= r.left - 8 && x <= r.right + 8 && y >= r.top - 8 && y <= r.bottom + 8
    }

    fun clearSelection() {
        if (selected.isEmpty()) return
        selected = emptySet(); dragDx = 0f; dragDy = 0f; dirty(); host?.selectionChanged(0)
    }

    fun deleteSelection() {
        if (selected.isEmpty()) return
        val sel = selected; selected = emptySet()
        commit(strokes.filter { it !in sel }); host?.selectionChanged(0)
    }

    fun recolorSelection(c: Int) {
        if (selected.isEmpty()) return
        val moved = HashSet<Ink.Stroke>()
        val next = strokes.map { if (it in selected) it.recolored(c).also { m -> moved.add(m) } else it }
        commit(next); selected = moved; dirty()
    }

    fun duplicateSelection() {
        if (selected.isEmpty()) return
        val copies = selected.map { it.moved(12f, 12f) }
        commit(strokes + copies); selected = copies.toSet(); dirty(); host?.selectionChanged(copies.size)
    }

    /* ---- finger scrolling (we take every touch in pen mode, so we scroll the page ourselves) ---- */
    private var scrollLastY = 0f
    private val samples = ArrayList<Pair<Long, Float>>()

    private fun avgRawY(e: MotionEvent, skip: Int = -1): Float {
        var sum = 0f; var n = 0
        for (i in 0 until e.pointerCount) { if (i == skip) continue; sum += e.getRawY(i); n++ }
        return if (n == 0) scrollLastY else sum / n
    }

    private fun startScroll(e: MotionEvent) {
        gesture = 2; scrollLastY = avgRawY(e); samples.clear()
        scroller()?.let { it.fling(0) }
    }

    private fun stopScroll() { if (gesture == 2) gesture = 0; samples.clear() }

    private fun scrollTouch(e: MotionEvent) {
        val sv = scroller() ?: return
        when (e.actionMasked) {
            MotionEvent.ACTION_POINTER_DOWN -> scrollLastY = avgRawY(e)
            MotionEvent.ACTION_POINTER_UP -> scrollLastY = avgRawY(e, e.actionIndex)
            MotionEvent.ACTION_MOVE -> {
                val y = avgRawY(e)
                sv.scrollBy(0, (scrollLastY - y).toInt())
                scrollLastY = y
                samples.add(e.eventTime to y); if (samples.size > 6) samples.removeAt(0)
                dirtyIfScrolledOut()
            }
            MotionEvent.ACTION_UP -> {
                if (samples.size >= 2) {
                    val (t0, y0) = samples.first(); val (t1, y1) = samples.last()
                    val dt = (t1 - t0).coerceAtLeast(1)
                    val v = (y0 - y1) / dt * 1000f
                    if (abs(v) > 200 && SystemClock.uptimeMillis() - t1 < 80) sv.fling(v.toInt())
                }
                gesture = 0
            }
        }
    }

    private fun dirtyIfScrolledOut() { invalidate() }

    /** Called by the page when it scrolls, so the recorded strokes cover what is on screen. */
    fun onScrolled() { invalidate() }
}
